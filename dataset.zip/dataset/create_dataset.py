import os

# Path to the source folder with JSONL files
source_folder = './problem-set/directed/'

# Path to the destination where new folders will be created
destination_folder = './dataset/directed/'

# Ensure the destination folder exists
os.makedirs(destination_folder, exist_ok=True)

# List all files in the source folder
for filename in os.listdir(source_folder):
    # Check if the file is a JSONL file
    if filename.endswith('.jsonl'):
        # Create a folder path by combining the destination folder and the file name without its extension
        folder_path = os.path.join(destination_folder, filename[:-6])  # remove last 6 characters, '.jsonl'

        # Create the folder
        os.makedirs(folder_path, exist_ok=True)

print('Folders created based on JSONL files.')
