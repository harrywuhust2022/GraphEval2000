import networkx as nx
import random
from typing import List
import collections
import json

def acyclic_sparse_graph(n):
    """ Generates an acyclic sparse graph with n nodes. """
    G = nx.DiGraph()
    G.add_nodes_from(range(n))
    for i in range(n):
        for j in range(i + 1, n):
            # Add an edge with a small probability to keep the graph sparse
            if random.random() < min(3/n, 1):
                G.add_edge(i, j)
    
    return list(G.edges())


def Gen_label(n, edges):
    weak = {b for a, b in edges}
    return -1 if len(weak) < n - 1 else n * (n - 1) // 2 - sum(weak)


def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [acyclic_sparse_graph]
    graph_labels = ["acyclic"]
    data = {label: {"graphs": [], "n": [], "labels": [], "complexity": []} for label in graph_labels}
    
    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            connection = graph_func(n)
            
            label_check = Gen_label(n, connection)  # Adjust the Gen_label parameters as needed
            data[label]["graphs"].append(connection)
            data[label]["n"].append(n)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(connection))  # Number of edges as a measure of complexity

    with open(filename, 'w') as file:
        for label, contents in data.items():
            jsonl_content = {label: contents}
            file.write(json.dumps(jsonl_content) + '\n')

# Example usage
generate_and_save_graphs(10, 20, 200, './dataset/directed/lc2924/sparse.jsonl')
