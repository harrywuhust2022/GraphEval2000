import networkx as nx
import json
import random

def generate_sparse_dag(num_nodes):
    """Generate a sparse directed acyclic graph with a given number of nodes."""
    G = nx.gn_graph(num_nodes, kernel=lambda x: 1 / x if x > 0 else 0, seed=random.randint(1, 1000))
    # Ensure the graph is acyclic
    if not nx.is_directed_acyclic_graph(G):
        return generate_sparse_dag(num_nodes)  # Retry if not a DAG
    return G


def convert_edges_to_adj_list(G):
    """Convert a graph's edge list to an adjacency list."""
    return [list(G.successors(i)) for i in range(G.number_of_nodes())]

def export_graphs_to_jsonl(filename, num_graphs):
    """Generate graphs and export them to a jsonl file."""
    data = {"acyclic": {"graphs": [], "labels": [], "complexity": []}}

    for _ in range(num_graphs):
        num_nodes = random.randint(20, 200)
        G = generate_sparse_dag(num_nodes)
        # edges = list(G.edges())
        adj_list = convert_edges_to_adj_list(G)
        label_check = Gen_label(adj_list)
        data["acyclic"]["graphs"].append(adj_list)
        data["acyclic"]["labels"].append(label_check)
        data["acyclic"]["complexity"].append(len(adj_list))

    with open(filename, 'w') as file:
        json.dump(data, file)


def Gen_label(graph):
    if not graph:
        return []

    d = {}
    for i in range(len(graph)):
        d[i] = graph[i]
    
    n = len(graph)
    stack = [(0, [0])]
    res = []
    while stack:
        node, path = stack.pop()
        if node == n - 1:
            res.append(path)
        for nei in d[node]:
            stack.append((nei, path+[nei]))
    return res

export_graphs_to_jsonl("./dataset/directed/lc797/sparse.jsonl", 10)
