import networkx as nx
import json
import random

def generate_planar_dag(num_nodes):
    """Generate a planar directed acyclic graph with a given number of nodes."""
    while True:
        G = nx.gn_graph(num_nodes, kernel=lambda x: 1 / x if x > 0 else 0, seed=random.randint(1, 1000))
        G = nx.DiGraph([(u, v) for u, v in G.edges() if u < v])  # Ensure directed edges go from lower to higher nodes
        if nx.is_directed_acyclic_graph(G) and nx.check_planarity(G.to_undirected())[0]:
            return G

def generate_planar_graph(num_nodes, connected=True, cyclic=True):
    """Generate a planar directed graph with a given number of nodes."""
    while True:
        G = nx.gn_graph(num_nodes, kernel=lambda x: 1 / x if x > 0 else 0, seed=random.randint(1, 1000))
        if not cyclic:
            G = nx.DiGraph([(u, v) for u, v in G.edges() if u < v])  # Ensure directed edges go from lower to higher nodes
        if connected and not nx.is_weakly_connected(G):
            continue  # Retry if the graph is not weakly connected
        if not connected and nx.is_weakly_connected(G):
            G.remove_edges_from(random.sample(G.edges(), 1))  # Disconnect the graph by removing a random edge
        if nx.check_planarity(G.to_undirected())[0]:
            return G


def convert_edges_to_adj_list(G):
    """Convert a graph's edge list to an adjacency list."""
    return [list(G.successors(i)) for i in range(G.number_of_nodes())]

def export_graphs_to_jsonl(filename, num_graphs):
    """Generate graphs and export them to a jsonl file."""
    data = {"acyclic": {"graphs": [], "labels": [], "complexity": []}}

    for _ in range(num_graphs):
        num_nodes = random.randint(20, 200)
        G = generate_planar_dag(num_nodes)
        # edges = list(G.edges())
        adj_list = convert_edges_to_adj_list(G)
        label_check = Gen_label(adj_list)
        data["acyclic"]["graphs"].append(adj_list)
        data["acyclic"]["labels"].append(label_check)
        data["acyclic"]["complexity"].append(len(adj_list))

    with open(filename, 'w') as file:
        json.dump(data, file)


def Gen_label(graph):
    if not graph:
        return []

    d = {}
    for i in range(len(graph)):
        d[i] = graph[i]
    
    n = len(graph)
    stack = [(0, [0])]
    res = []
    while stack:
        node, path = stack.pop()
        if node == n - 1:
            res.append(path)
        for nei in d[node]:
            stack.append((nei, path+[nei]))
    return res

export_graphs_to_jsonl("../../../dataset/directed/lc797/planar.jsonl", 10)
