import json
import networkx as nx
import random

def connected_planar_digraph(numCourses):
    G = nx.DiGraph()
    G.add_node(0)
    for i in range(1, numCourses):
        G.add_edge(random.randint(0, i-1), i)
    return G

def disconnected_planar_digraph(numCourses):
    G = nx.DiGraph()
    partition_point = random.randint(1, numCourses - 1)
    for i in range(1, partition_point):
        if random.random() > 0.5:
            G.add_edge(random.randint(0, i-1), i)
    for i in range(partition_point + 1, numCourses):
        if random.random() > 0.5:
            G.add_edge(random.randint(partition_point, i-1), i)
    return G

def cyclic_planar_digraph(numCourses):
    G = nx.DiGraph()
    cycle_length = random.randint(3, numCourses)
    cycle_nodes = list(range(cycle_length))
    G.add_edges_from((cycle_nodes[i], cycle_nodes[(i+1) % cycle_length]) for i in range(cycle_length))
    return G

def acyclic_planar_digraph(numCourses):
    G = nx.DiGraph()
    G.add_nodes_from(range(numCourses))
    for i in range(1, numCourses):
        G.add_edge(random.randint(0, i-1), i)
    return G

def Gen_label(numCourses, prerequisites):
    preMap = {i: [] for i in range(numCourses)}
    for crs, pre in prerequisites:
        preMap[crs].append(pre)

    res = []
    visit = set()
    cycle = set()

    def dfs(crs):
        if crs in visit:
            return True
        if crs in cycle:
            return False

        cycle.add(crs)

        for pre in preMap[crs]:
            if not dfs(pre):
                return False

        cycle.remove(crs)
        res.append(crs)
        visit.add(crs)

        return True

    for crs in range(numCourses):
        if not dfs(crs):
            return []

    return res

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [connected_planar_digraph, disconnected_planar_digraph, cyclic_planar_digraph, acyclic_planar_digraph]
    graph_labels = ["connected", "disconnected", "cyclic", "acyclic"]
    data = {label: {"graphs": [], "numCourse": [], "labels": [], "complexity": []} for label in graph_labels}
    
    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            G = graph_func(n)
            print(nx.is_planar(G))
            edges = list(G.edges())
            label_check = Gen_label(n, edges)
            data[label]["numCourse"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(edges))

    with open(filename, 'w') as file:
        for key, value in data.items():
            file.write(json.dumps({key: value}) + '\n')

if __name__ == '__main__':
    generate_and_save_graphs(10, 20, 200, '../../../dataset/directed/lc210/planar.jsonl')
