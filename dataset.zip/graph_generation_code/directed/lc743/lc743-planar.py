import json
import networkx as nx
import random
from collections import defaultdict
import heapq

def ensure_planarity(graph_func):
    def wrapper(n):
        while True:
            G = graph_func(n)
            if nx.is_planar(G.to_undirected()):
                return G
    return wrapper

@ensure_planarity
def connected_planar_digraph(n):
    G = nx.DiGraph()
    G.add_node(1)
    for i in range(2, n + 1):
        G.add_edge(random.randint(1, i-1), i, weight=random.randint(1, 100))
    return G

@ensure_planarity
def disconnected_planar_digraph(n):
    G = nx.DiGraph()
    partition = random.randint(1, n - 1)
    for i in range(1, partition + 1):
        if random.random() > 0.5:
            G.add_edge(random.randint(1, partition), random.randint(1, partition), weight=random.randint(1, 100))
    for i in range(partition + 1, n + 1):
        if random.random() > 0.5:
            G.add_edge(random.randint(partition + 1, n), random.randint(partition + 1, n), weight=random.randint(1, 100))
    return G

@ensure_planarity
def cyclic_planar_digraph(n):
    G = nx.DiGraph()
    nodes = list(range(1, n + 1))
    random.shuffle(nodes)
    for i in range(n):
        G.add_edge(nodes[i], nodes[(i + 1) % n], weight=random.randint(1, 100))
    return G

@ensure_planarity
def acyclic_planar_digraph(n):
    G = nx.DiGraph()
    G.add_nodes_from(range(1, n + 1))
    layers = {i: i // (n // 3 + 1) for i in range(1, n + 1)}
    for i in range(1, n + 1):
        for j in range(i + 1, n + 1):
            if layers[i] < layers[j] and random.random() < 0.3:
                G.add_edge(i, j, weight=random.randint(1, 100))
    return G

def Gen_label(times, n, k):
    adj = defaultdict(list)
    for src, tar, time in times:
        adj[src].append((tar, time))
    visit = set()
    minH = [[0, k]]
    t = 0

    while minH:
        w1, n1 = heapq.heappop(minH)
        if n1 in visit:
            continue
        visit.add(n1)
        t = w1

        for n2, w2 in adj[n1]:
            if n2 not in visit:
                heapq.heappush(minH, [w1 + w2, n2])

    return t if len(visit) == n else -1

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [connected_planar_digraph, disconnected_planar_digraph, cyclic_planar_digraph]
    graph_labels = ["connected", "disconnected", "cyclic"]
    data = {label: {"graphs": [], "n": [], "k": [], "labels": [], "complexity": []} for label in graph_labels}

    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            k = random.randint(1, n)
            print(label)
            G = graph_func(n)
            print(nx.is_planar(G))
            edges = list(G.edges(data='weight'))
            label_check = Gen_label(edges, n, k)
            data[label]["n"].append(n)
            data[label]["k"].append(k)
            data[label]["graphs"].append(edges)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(edges))

    with open(filename, 'w') as file:
        for key, value in data.items():
            file.write(json.dumps({key: value}) + '\n')

if __name__ == '__main__':
    generate_and_save_graphs(10, 20, 200, '../../../dataset/directed/lc743/planar.jsonl')
