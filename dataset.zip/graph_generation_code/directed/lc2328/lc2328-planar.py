import networkx as nx
import random
from typing import List
import collections
import json

def generate_planar_directed_grid_graph(m, n):
    """Generates a connected planar directed grid graph with m rows and n columns."""
    G = nx.DiGraph()
    for i in range(m):
        for j in range(n):
            if j + 1 < n:
                G.add_edge((i, j), (i, j + 1))
            if i + 1 < m:
                G.add_edge((i, j), (i + 1, j))
    return G

def generate_random_planar_directed_grid():
    m = random.randint(20, 200)
    n = random.randint(20, 200)
    
    # Ensure that the total number of cells does not exceed 100000
    while m * n > 100000:
        m = random.randint(20, 200)
        n = random.randint(20, 200)
    
    G = generate_planar_directed_grid_graph(m, n)
    
    # Generate random weights for the grid cells
    grid = [[random.randint(1, 100000) for _ in range(n)] for _ in range(m)]
    
    return list(G.edges()), grid

def Gen_label(A):
    m, n, mod = len(A), len(A[0]), 10 ** 9 + 7
    dp = [[1] * n for i in range(m)]
    for a, i, j in sorted([A[i][j], i, j] for i in range(m) for j in range(n)):
        for x, y in [[i, j + 1], [i, j - 1], [i + 1, j], [i - 1, j]]:
            if 0 <= x < m and 0 <= y < n and A[x][y] < A[i][j]:
                dp[i][j] += dp[x][y] % mod
    return sum(map(sum, dp)) % mod

def generate_and_save_graphs(num_graphs, filename):
    graph_types = [generate_random_planar_directed_grid]
    graph_labels = ["connected"]
    data = {label: {"graphs": [], "labels": [], "complexity": []} for label in graph_labels}
    
    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            connections, grid = graph_func()
            
            label_check = Gen_label(grid)  # Adjust the Gen_label parameters as needed
            data[label]["graphs"].append(connections)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(connections))  # Number of edges as a measure of complexity

    with open(filename, 'w') as file:
        for label, contents in data.items():
            jsonl_content = {label: contents}
            file.write(json.dumps(jsonl_content) + '\n')

# Example usage
generate_and_save_graphs(10, '../../../dataset/directed/lc2328/planar.jsonl')
