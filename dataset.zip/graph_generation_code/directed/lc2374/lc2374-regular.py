import networkx as nx
import random
from typing import List
import collections
import json

def generate_graph_test_case():
    n = random.randint(20, 200)
    edges = [-1] * n
    for i in range(n):
        choices = list(range(n))
        choices.remove(i)
        edges[i] = random.choice(choices)
    
    return edges

def Gen_label(edges):
    score = collections.defaultdict(int)
    for u, v in enumerate(edges):
        score[v] += u
    
    return max(score, key=lambda x: (score[x], -x))

def generate_and_save_graphs(num_graphs, filename):
    graph_types = [generate_graph_test_case]
    graph_labels = ["connected"]
    data = {label: {"graphs": [], "labels": [], "complexity": []} for label in graph_labels}
    
    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            connection = graph_func()
            label_check = Gen_label(connection)  # Adjust the Gen_label parameters as needed
            data[label]["graphs"].append(connection)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(connection))  # Number of edges as a measure of complexity

    with open(filename, 'w') as file:
        for label, contents in data.items():
            jsonl_content = {label: contents}
            file.write(json.dumps(jsonl_content) + '\n')

# Example usage
generate_and_save_graphs(10, './dataset/directed/lc2374/regular.jsonl')
