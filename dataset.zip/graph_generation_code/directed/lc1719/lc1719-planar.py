import networkx as nx
import random
from typing import List
from collections import *
import json

def is_planar(G):
    """Check if a graph is planar."""
    return nx.check_planarity(G.to_undirected())[0]

def acyclic_planar_graph(n):
    """Generate a planar directed acyclic graph (DAG) with a given number of nodes."""
    while True:
        G = nx.DiGraph()
        G.add_nodes_from(range(1, n + 1))
        for i in range(1, n):
            for j in range(i + 1, n + 1):
                if random.random() < 0.1:  # Adding edges sparsely
                    G.add_edge(i, j)
        if nx.is_directed_acyclic_graph(G) and is_planar(G):
            return list(G.edges())

def cyclic_planar_graph(n):
    """Generate a planar directed cyclic graph with a given number of nodes."""
    while True:
        G = nx.DiGraph()
        G.add_nodes_from(range(1, n + 1))
        for i in range(1, n):
            for j in range(i + 1, n + 1):
                if random.random() < 0.05:  # Adding edges sparsely
                    G.add_edge(i, j)
                if random.random() < 0.05:  # Adding edges sparsely
                    G.add_edge(j, i)
        for _ in range(n // 10):
            n1, n2 = random.sample(range(1, n + 1), 2)
            G.add_edge(n1, n2)
            G.add_edge(n2, n1)
        if len(list(nx.simple_cycles(G))) > 0 and is_planar(G):
            return list(G.edges())

def connected_planar_graph(n):
    """Generate a planar connected undirected graph with a given number of nodes."""
    while True:
        G = nx.Graph()
        G.add_nodes_from(range(1, n + 1))
        while not nx.is_connected(G):
            u, v = random.sample(range(1, n + 1), 2)
            if not G.has_edge(u, v):
                G.add_edge(u, v)
        if is_planar(G):
            return list(G.edges())

def disconnected_planar_graph(n):
    """Generate a planar disconnected undirected graph with a given number of nodes."""
    while True:
        G = nx.Graph()
        G.add_nodes_from(range(1, n + 1))
        component_size = n // 2
        component1 = list(range(1, component_size + 1))
        component2 = list(range(component_size + 1, n + 1))
        for u in component1:
            for v in component1:
                if u != v and random.random() < 0.1:
                    G.add_edge(u, v)
        for u in component2:
            for v in component2:
                if u != v and random.random() < 0.1:
                    G.add_edge(u, v)
        if nx.number_connected_components(G) > 1 and is_planar(G):
            return list(G.edges())

# Update function names to match the original graph types used in generate_and_save_graphs
def acyclic_graph(n):
    return acyclic_planar_graph(n)

def cyclic_graph(n):
    return cyclic_planar_graph(n)

def connected_graph(n):
    return connected_planar_graph(n)

def disconnected_graph(n):
    return disconnected_planar_graph(n)

def Gen_label(pairs):
    nodes, graph, degree = set(), defaultdict(set), defaultdict(int)
    for i, j in pairs:
        nodes |= {i, j}
        graph[i].add(j)
        graph[j].add(i)
        degree[i] += 1
        degree[j] += 1
    if max(degree.values()) < len(nodes) - 1:
        return 0
    for n in nodes:
        if degree[n] < len(nodes) - 1:
            neighbor = set()
            for nn in graph[n]:
                if degree[n] >= degree[nn]:
                    neighbor |= graph[nn]
            if neighbor - {n} - graph[n]:
                return 0
    for n in nodes:
        if any(degree[n] == degree[nn] for nn in graph[n]):
            return 2
    return 1

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [acyclic_graph, cyclic_graph, connected_graph, disconnected_graph]
    graph_labels = ["acyclic", "cyclic", "connected", "disconnected"]
    data = {
        label: {"graphs": [], "labels": [], "complexity": []} for label in graph_labels
    }

    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            connection = graph_func(n)

            label_check = Gen_label(connection)  # Adjust the Gen_label parameters as needed
            data[label]["graphs"].append(connection)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(
                len(connection)
            )  # Number of edges as a measure of complexity

    with open(filename, "w") as file:
        for label, contents in data.items():
            jsonl_content = {label: contents}
            file.write(json.dumps(jsonl_content) + "\n")


# Example usage
generate_and_save_graphs(10, 20, 30, "../../../dataset/directed/lc1719/planar.jsonl")
