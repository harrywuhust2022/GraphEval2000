import networkx as nx
import random
from typing import List
from collections import *
import json


def acyclic_graph(num_nodes):
    """Generate a random acyclic graph (DAG) with a given number of nodes."""
    G = nx.DiGraph()
    G.add_nodes_from(range(1, num_nodes + 1))

    for i in range(1, num_nodes):
        for j in range(i + 1, num_nodes + 1):
            if random.random() < 0.1:  # Adding edges sparsely
                G.add_edge(i, j)

    # Ensure the graph is acyclic
    if not nx.is_directed_acyclic_graph(G):
        return acyclic_graph(num_nodes)

    return list(G.edges())


def cyclic_graph(num_nodes):
    """Generate a random cyclic graph with a given number of nodes."""
    G = nx.DiGraph()
    G.add_nodes_from(range(1, num_nodes + 1))

    for i in range(1, num_nodes):
        for j in range(i + 1, num_nodes + 1):
            if random.random() < 0.05:  # Adding edges sparsely
                G.add_edge(i, j)
            if random.random() < 0.05:  # Adding edges sparsely
                G.add_edge(j, i)

    # Add some cycles
    for _ in range(num_nodes // 10):
        n1, n2 = random.sample(range(1, num_nodes + 1), 2)
        G.add_edge(n1, n2)
        G.add_edge(n2, n1)

    return list(G.edges())


def connected_graph(num_nodes):
    """Generate a random connected undirected graph with a given number of nodes."""
    G = nx.Graph()
    G.add_nodes_from(range(1, num_nodes + 1))

    while not nx.is_connected(G):
        u, v = random.sample(range(1, num_nodes + 1), 2)
        if not G.has_edge(u, v):
            G.add_edge(u, v)

    return list(G.edges())


def disconnected_graph(num_nodes):
    """Generate a random disconnected undirected graph with a given number of nodes."""
    G = nx.Graph()
    G.add_nodes_from(range(1, num_nodes + 1))

    # Create two connected components
    component_size = num_nodes // 2
    component1 = list(range(1, component_size + 1))
    component2 = list(range(component_size + 1, num_nodes + 1))

    for u in component1:
        for v in component1:
            if u != v and random.random() < 0.1:
                G.add_edge(u, v)

    for u in component2:
        for v in component2:
            if u != v and random.random() < 0.1:
                G.add_edge(u, v)

    return list(G.edges())


def Gen_label(pairs):
    nodes, graph, degree = set(), defaultdict(set), defaultdict(int)
    for i, j in pairs:
        nodes |= {i, j}
        graph[i].add(j)
        graph[j].add(i)
        degree[i] += 1
        degree[j] += 1
    if max(degree.values()) < len(nodes) - 1:
        return 0
    for n in nodes:
        if degree[n] < len(nodes) - 1:
            neighbor = set()
            for nn in graph[n]:
                if degree[n] >= degree[nn]:
                    neighbor |= graph[nn]
            if neighbor - {n} - graph[n]:
                return 0
    for n in nodes:
        if any(degree[n] == degree[nn] for nn in graph[n]):
            return 2
    return 1


def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [acyclic_graph, cyclic_graph, connected_graph, disconnected_graph]
    graph_labels = ["acyclic", "cyclic", "connected", "disconnected"]
    data = {
        label: {"graphs": [], "labels": [], "complexity": []} for label in graph_labels
    }

    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            connection = graph_func(n)

            label_check = Gen_label(connection)  # Adjust the Gen_label parameters as needed
            data[label]["graphs"].append(connection)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(
                len(connection)
            )  # Number of edges as a measure of complexity

    with open(filename, "w") as file:
        for label, contents in data.items():
            jsonl_content = {label: contents}
            file.write(json.dumps(jsonl_content) + "\n")


# Example usage
generate_and_save_graphs(10, 20, 200, "./dataset/directed/lc1719/sparse.jsonl")
