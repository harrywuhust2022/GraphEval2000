import networkx as nx
import random
from typing import List
import collections
import json

def generate_time_list(n, min_time=1, max_time=1000):
    time_list = [random.randint(min_time, max_time) for _ in range(n)]
    return time_list

def connected_sparse_graph(n):
    """ Generates a connected sparse graph with n nodes. """
    G = nx.generators.random_graphs.fast_gnp_random_graph(n, p=min(5/n, 1), directed=True)
    while not nx.is_strongly_connected(G):
        G = nx.generators.random_graphs.fast_gnp_random_graph(n, p=min(5/n, 1), directed=True)

    time = generate_time_list(n)
    return list(G.edges()), time

def disconnected_sparse_graph(n):
    """ Generates a disconnected sparse graph with n nodes, ensuring at least two components. """
    G = nx.generators.random_graphs.fast_gnp_random_graph(n, p=min(2/n, 1), directed=True)
    # Ensure the graph is disconnected by manually disconnecting parts
    if n > 1:
        G.remove_edge(0, 1) if G.has_edge(0, 1) else None
    
    time = generate_time_list(n)
    return list(G.edges()), time

def cyclic_sparse_graph(n):
    """ Generates a cyclic sparse graph with n nodes. """
    G = nx.DiGraph()
    nodes = list(range(n))
    random.shuffle(nodes)
    for i in range(n):
        if i < n - 1:
            G.add_edge(nodes[i], nodes[i+1])
        else:
            G.add_edge(nodes[i], nodes[0])  # Creating a cycle
    
    time = generate_time_list(n)
    return list(G.edges()), time

def acyclic_sparse_graph(n):
    """ Generates an acyclic sparse graph with n nodes. """
    G = nx.DiGraph()
    G.add_nodes_from(range(n))
    for i in range(n):
        for j in range(i + 1, n):
            # Add an edge with a small probability to keep the graph sparse
            if random.random() < min(3/n, 1):
                G.add_edge(i, j)
    
    time = generate_time_list(n)
    return list(G.edges()), time


def Gen_label(n, relations, time):
    graph = collections.defaultdict(list)
    inDegree = [0] * n
    for prv, nxt in relations:
        prv, nxt = prv - 1, nxt - 1
        graph[prv].append(nxt)
        inDegree[nxt] += 1

    q = collections.deque([])
    dist = [0] * n
    for u in range(n):
        if inDegree[u] == 0:
            q.append(u)
            dist[u] = time[u]

    while q:
        u = q.popleft()
        for v in graph[u]:
            dist[v] = max(dist[u] + time[v], dist[v])
            inDegree[v] -= 1
            if inDegree[v] == 0:
                q.append(v)
    return max(dist)


def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [connected_sparse_graph, disconnected_sparse_graph, cyclic_sparse_graph, acyclic_sparse_graph]
    graph_labels = ["connected", "disconnected", "cyclic", "acyclic"]
    data = {label: {"graphs": [], "n": [], "time": [], "labels": [], "complexity": []} for label in graph_labels}
    
    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            relations, time = graph_func(n)
            
            label_check = Gen_label(n, relations, time)  # Adjust the Gen_label parameters as needed
            data[label]["graphs"].append(relations)
            data[label]["n"].append(n)
            data[label]["time"].append(time)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(relations))  # Number of edges as a measure of complexity

    with open(filename, 'w') as file:
        for label, contents in data.items():
            jsonl_content = {label: contents}
            file.write(json.dumps(jsonl_content) + '\n')

# Example usage
generate_and_save_graphs(10, 20, 200, './dataset/directed/lc2050/sparse.jsonl')
