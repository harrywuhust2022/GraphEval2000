import networkx as nx
import random
from typing import List
import collections
import json

def convert_edge_tuples_to_array(edge_tuples):
    n = max(max(edge) for edge in edge_tuples) + 1
    edges = [-1] * n
    for start, end in edge_tuples:
        edges[start] = end
    
    return edges

def is_planar(G):
    """Check if a graph is planar."""
    return nx.check_planarity(G.to_undirected())[0]

def connected_planar_graph(n):
    """Generates a connected planar graph with n nodes."""
    while True:
        G = nx.gnm_random_graph(n, n-1, directed=True)
        if nx.is_strongly_connected(G) and is_planar(G):
            return convert_edge_tuples_to_array(list(G.edges()))

def disconnected_planar_graph(n):
    """Generates a disconnected planar graph with n nodes, ensuring at least two components."""
    while True:
        G = nx.gnp_random_graph(n, p=min(2/n, 1), directed=True)
        if not nx.is_strongly_connected(G) and nx.number_strongly_connected_components(G) > 1 and is_planar(G):
            return convert_edge_tuples_to_array(list(G.edges()))

def cyclic_planar_graph(n):
    """Generates a cyclic planar graph with n nodes."""
    while True:
        G = nx.DiGraph()
        nodes = list(range(n))
        random.shuffle(nodes)
        for i in range(n):
            if i < n - 1:
                G.add_edge(nodes[i], nodes[i + 1])
            else:
                G.add_edge(nodes[i], nodes[0])  # Creating a cycle
        if len(list(nx.simple_cycles(G))) > 0 and is_planar(G):
            return convert_edge_tuples_to_array(list(G.edges()))

def acyclic_planar_graph(n):
    """Generates an acyclic planar graph with n nodes."""
    while True:
        G = nx.DiGraph()
        G.add_nodes_from(range(n))
        for i in range(n):
            for j in range(i + 1, n):
                if random.random() < min(3/n, 1):
                    G.add_edge(i, j)
        if nx.is_directed_acyclic_graph(G) and is_planar(G):
            return convert_edge_tuples_to_array(list(G.edges()))

# Update function names to match the original graph types used in generate_and_save_graphs
def connected_sparse_graph(n):
    return connected_planar_graph(n)

def disconnected_sparse_graph(n):
    return disconnected_planar_graph(n)

def cyclic_sparse_graph(n):
    return cyclic_planar_graph(n)

def acyclic_sparse_graph(n):
    return acyclic_planar_graph(n)

def Gen_label(edges):
    ans = -1
    time = 1
    timeVisited = [0] * len(edges)

    for i in range(len(edges)):
        if timeVisited[i]:
            continue
        startTime = time
        u = i
        while u != -1 and not timeVisited[u]:
            timeVisited[u] = time
            time += 1
            u = edges[u]
        if u != -1 and timeVisited[u] >= startTime:
            ans = max(ans, time - timeVisited[u])

    return ans

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [disconnected_sparse_graph, cyclic_sparse_graph, acyclic_sparse_graph]
    graph_labels = ["disconnected", "cyclic", "acyclic"]
    data = {label: {"graphs": [], "labels": [], "complexity": []} for label in graph_labels}
    
    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            connection = graph_func(n)
            
            label_check = Gen_label(connection)  # Adjust the Gen_label parameters as needed
            data[label]["graphs"].append(connection)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(connection))  # Number of edges as a measure of complexity

    with open(filename, 'w') as file:
        for label, contents in data.items():
            jsonl_content = {label: contents}
            file.write(json.dumps(jsonl_content) + '\n')

# Example usage
generate_and_save_graphs(10, 20, 35, '../../../dataset/directed/lc2360/planar.jsonl')
