import networkx as nx
import random
from typing import List
import collections
import json

def generate_quiet_list(n):
    """ Generates a quiet list with unique values from 0 to n-1, shuffled. """
    quiet = list(range(n))
    random.shuffle(quiet)
    return quiet

def connected_sparse_graph(n):
    """ Generates a connected sparse graph with n nodes. """
    G = nx.generators.random_graphs.fast_gnp_random_graph(n, p=min(5/n, 1), directed=True)
    while not nx.is_strongly_connected(G):
        G = nx.generators.random_graphs.fast_gnp_random_graph(n, p=min(5/n, 1), directed=True)
    
    quiet = generate_quiet_list(n)
    return list(G.edges()), quiet

def disconnected_sparse_graph(n):
    """ Generates a disconnected sparse graph with n nodes, ensuring at least two components. """
    G = nx.generators.random_graphs.fast_gnp_random_graph(n, p=min(2/n, 1), directed=True)
    # Ensure the graph is disconnected by manually disconnecting parts
    if n > 1:
        G.remove_edge(0, 1) if G.has_edge(0, 1) else None
    
    quiet = generate_quiet_list(n)
    return list(G.edges()), quiet

def cyclic_sparse_graph(n):
    """ Generates a cyclic sparse graph with n nodes. """
    G = nx.DiGraph()
    nodes = list(range(n))
    random.shuffle(nodes)
    for i in range(n):
        if i < n - 1:
            G.add_edge(nodes[i], nodes[i+1])
        else:
            G.add_edge(nodes[i], nodes[0])  # Creating a cycle
    
    quiet = generate_quiet_list(n)
    return list(G.edges()), quiet

def acyclic_sparse_graph(n):
    """ Generates an acyclic sparse graph with n nodes. """
    G = nx.DiGraph()
    G.add_nodes_from(range(n))
    for i in range(n):
        for j in range(i + 1, n):
            # Add an edge with a small probability to keep the graph sparse
            if random.random() < min(3/n, 1):
                G.add_edge(i, j)
    
    quiet = generate_quiet_list(n)
    return list(G.edges()), quiet


def Gen_label(richer, quiet):
    m = collections.defaultdict(list)
    for i, j in richer: m[j].append(i)
    res = [-1] * len(quiet)

    def dfs(i):
        if res[i] >= 0: return res[i]
        res[i] = i
        for j in m[i]:
            if quiet[res[i]] > quiet[dfs(j)]: res[i] = res[j]
        return res[i]

    for i in range(len(quiet)): dfs(i)
    return res


def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [connected_sparse_graph, disconnected_sparse_graph, cyclic_sparse_graph, acyclic_sparse_graph]
    graph_labels = ["connected", "disconnected", "cyclic", "acyclic"]
    data = {label: {"graphs": [], "quiet": [], "labels": [], "complexity": []} for label in graph_labels}
    
    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            richer, quiet = graph_func(n)
            
            label_check = Gen_label(richer, quiet)  # Adjust the Gen_label parameters as needed
            data[label]["graphs"].append(richer)
            data[label]["quiet"].append(quiet)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(richer))  # Number of edges as a measure of complexity

    with open(filename, 'w') as file:
        for label, contents in data.items():
            jsonl_content = {label: contents}
            file.write(json.dumps(jsonl_content) + '\n')

# Example usage
generate_and_save_graphs(10, 20, 200, './dataset/directed/lc851/sparse.jsonl')
