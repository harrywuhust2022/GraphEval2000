import networkx as nx
import matplotlib.pyplot as plt
import random
import collections
import json

def connected_pseudo_graph(n):
    G = nx.DiGraph(nx.path_graph(n))
    G.add_edge(0, 0)
    return G

def disconnected_pseudo_graph(n):
    G = nx.DiGraph()
    subgraph_size = n // 2
    G.add_nodes_from(range(n))
    nx.add_path(G, range(subgraph_size))
    nx.add_path(G, range(subgraph_size, n))
    G.add_edge(0, 0)
    return G

def cyclic_pseudo_graph(n):
    G = nx.DiGraph(nx.cycle_graph(n))
    G.add_edge(0, 0)
    return G

def acyclic_pseudo_graph(n):
    G = nx.DiGraph(nx.gnp_random_graph(n, 0.1, directed=True))
    try:
        cycle = nx.find_cycle(G, orientation='original')
        for u, v, _ in cycle:
            G.remove_edge(u, v)
    except:
        pass
    G.add_edge(0, 0)
    return G

def convert_to_adj_list(G):
    return [list(G.successors(node)) for node in range(len(G.nodes()))]

def Gen_label(graph):
    n = len(graph)
    out_degree = collections.defaultdict(int)
    in_nodes = collections.defaultdict(list) 
    queue = []
    ret = []
    for i in range(n):
        out_degree[i] = len(graph[i])
        if out_degree[i]==0:
            queue.append(i)
        for j in graph[i]:
            in_nodes[j].append(i)  
    while queue:
        term_node = queue.pop(0)
        ret.append(term_node)
        for in_node in in_nodes[term_node]:
            out_degree[in_node] -= 1
            if out_degree[in_node]==0:
                queue.append(in_node)
    return sorted(ret)


def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [connected_pseudo_graph, disconnected_pseudo_graph, 
                   cyclic_pseudo_graph, acyclic_pseudo_graph]
    graph_labels = ["connected", "disconnected", "cyclic", "acyclic"]
    data = {label: {"graphs": [], "labels": [], "complexity": []} for label in graph_labels}
    
    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            G = graph_func(n)
            adj_list = convert_to_adj_list(G)

            label_check = Gen_label(adj_list)
            data[label]["graphs"].append(adj_list)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(adj_list))

    with open(filename, 'w') as file:
        for label, contents in data.items():
            jsonl_content = {label: contents}
            file.write(json.dumps(jsonl_content) + '\n')

generate_and_save_graphs(10, 20, 200, './dataset/directed/lc802/pseudo.jsonl')