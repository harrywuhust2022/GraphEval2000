import networkx as nx
import random
from typing import List
import collections
import json

def is_planar(G):
    """Check if a graph is planar."""
    return nx.check_planarity(G.to_undirected())[0]

# def connected_planar_graph(n):
#     """Generates a connected planar graph with n nodes."""
#     while True:
#         G = nx.generators.random_graphs.gnp_random_graph(n, p=min(5/n, 1), directed=True)
#         if nx.is_strongly_connected(G) and is_planar(G):
#             return [list(G.successors(i)) for i in range(G.number_of_nodes())]

def disconnected_planar_graph(n):
    """Generates a disconnected planar graph with n nodes, ensuring at least two components."""
    while True:
        G = nx.generators.random_graphs.gnp_random_graph(n, p=min(2/n, 1), directed=True)
        if not nx.is_strongly_connected(G) and nx.number_strongly_connected_components(G) > 1 and is_planar(G):
            return [list(G.successors(i)) for i in range(G.number_of_nodes())]

# def cyclic_planar_graph(n):
#     """Generates a cyclic planar graph with n nodes."""
#     while True:
#         G = nx.generators.random_graphs.gnp_random_graph(n, p=min(5/n, 1), directed=True)
#         if len(list(nx.simple_cycles(G))) > 0 and is_planar(G):
#             return [list(G.successors(i)) for i in range(G.number_of_nodes())]

# def acyclic_planar_graph(n):
#     """Generates an acyclic planar graph with n nodes."""
#     while True:
#         G = nx.generators.random_graphs.gnp_random_graph(n, p=min(3/n, 1), directed=True)
#         if nx.is_directed_acyclic_graph(G) and is_planar(G):
#             return [list(G.successors(i)) for i in range(G.number_of_nodes())]


def Gen_label(graph):
    n = len(graph)
    out_degree = collections.defaultdict(int)
    in_nodes = collections.defaultdict(list) 
    queue = []
    ret = []
    for i in range(n):
        out_degree[i] = len(graph[i])
        if out_degree[i]==0:
            queue.append(i)
        for j in graph[i]:
            in_nodes[j].append(i)  
    while queue:
        term_node = queue.pop(0)
        ret.append(term_node)
        for in_node in in_nodes[term_node]:
            out_degree[in_node] -= 1
            if out_degree[in_node]==0:
                queue.append(in_node)
    return sorted(ret)


def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [disconnected_planar_graph]
    graph_labels = ["disconnected"]
    data = {label: {"graphs": [], "labels": [], "complexity": []} for label in graph_labels}
    
    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            print(label)
            n = random.randint(min_n, max_n)
            adj_list = graph_func(n)
            label_check = Gen_label(adj_list)  # Adjust the Gen_label parameters as needed
            data[label]["graphs"].append(adj_list)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(adj_list))  # Number of edges as a measure of complexity

    with open(filename, 'w') as file:
        for label, contents in data.items():
            jsonl_content = {label: contents}
            file.write(json.dumps(jsonl_content) + '\n')

# Example usage
generate_and_save_graphs(10, 20, 25, '../../../dataset/directed/lc802/planar.jsonl')
