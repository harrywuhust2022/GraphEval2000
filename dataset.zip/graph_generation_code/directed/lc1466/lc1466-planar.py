import networkx as nx
import random
from typing import List
import collections
import json

def is_planar(G):
    """Check if a graph is planar."""
    return nx.check_planarity(G.to_undirected())[0]

def connected_planar_graph(n):
    """Generates a connected planar graph with n nodes."""
    while True:
        G = nx.gnm_random_graph(n, n-1, directed=True)
        if nx.is_strongly_connected(G) and is_planar(G):
            return list(G.edges())

def disconnected_planar_graph(n):
    """Generates a disconnected planar graph with n nodes, ensuring at least two components."""
    while True:
        G = nx.gnp_random_graph(n, p=min(2/n, 1), directed=True)
        if not nx.is_strongly_connected(G) and nx.number_strongly_connected_components(G) > 1 and is_planar(G):
            return list(G.edges())

def cyclic_planar_graph(n):
    """Generates a cyclic planar graph with n nodes."""
    while True:
        G = nx.DiGraph()
        nodes = list(range(n))
        random.shuffle(nodes)
        for i in range(n):
            if i < n - 1:
                G.add_edge(nodes[i], nodes[i+1])
            else:
                G.add_edge(nodes[i], nodes[0])  # Creating a cycle
        if len(list(nx.simple_cycles(G))) > 0 and is_planar(G):
            return list(G.edges())

def acyclic_planar_graph(n):
    """Generates an acyclic planar graph with n nodes."""
    while True:
        G = nx.DiGraph()
        G.add_nodes_from(range(n))
        for i in range(n):
            for j in range(i + 1, n):
                if random.random() < min(3/n, 1):
                    G.add_edge(i, j)
        if nx.is_directed_acyclic_graph(G) and is_planar(G):
            return list(G.edges())

# Ensure these function names match the original graph types used in generate_and_save_graphs
def connected_sparse_graph(n):
    return connected_planar_graph(n)

def disconnected_sparse_graph(n):
    return disconnected_planar_graph(n)

def cyclic_sparse_graph(n):
    return cyclic_planar_graph(n)

def acyclic_sparse_graph(n):
    return acyclic_planar_graph(n)

def Gen_label(n, connections):
    cmap = {0}
    count = 0
    dq = collections.deque(connections)
    while dq:
        u, v = dq.popleft()
        if v in cmap:
            cmap.add(u)
        elif u in cmap:
            cmap.add(v)
            count += 1
        else:
            dq.append([u, v])
    return count

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [cyclic_sparse_graph]
    graph_labels = ["cyclic"]
    data = {label: {"graphs": [], "n": [], "labels": [], "complexity": []} for label in graph_labels}
    
    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            print(label)
            n = random.randint(min_n, max_n)
            connection = graph_func(n)
            
            label_check = Gen_label(n, connection)  # Adjust the Gen_label parameters as needed
            data[label]["graphs"].append(connection)
            data[label]["n"].append(n)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(connection))  # Number of edges as a measure of complexity

    with open(filename, 'w') as file:
        for label, contents in data.items():
            jsonl_content = {label: contents}
            file.write(json.dumps(jsonl_content) + '\n')

# Example usage
generate_and_save_graphs(10, 20, 200, '../../../dataset/directed/lc1466/planar.jsonl')
