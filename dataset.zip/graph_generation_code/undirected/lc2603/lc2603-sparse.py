from collections import defaultdict, deque
import math
from typing import Counter, List
import networkx as nx
import json
import random

def generate_tree_graph(n):
    # Generate a tree with n nodes
    return nx.random_tree(n, seed=random.randint(1, 1000))

def gen_label(coins: List[int], edges: List[List[int]]) -> int:
    n = len(coins)
    tree = [set() for _ in range(n)]
    
    # Build the tree from the edges
    for e in edges:
        tree[e[0]].add(e[1])
        tree[e[1]].add(e[0])
    
    # Find the leaves with zero coins
    leaf = []
    for i in range(n):
        u = i
        while len(tree[u]) == 1 and coins[u] == 0:
            v = tree[u].pop()
            tree[v].remove(u)
            u = v
        if len(tree[u]) == 1:
            leaf.append(u)
    
    # Remove the leaves one by one
    for sz in range(2, 0, -1):
        temp = []
        for u in leaf:
            if len(tree[u]) == 1:
                v = tree[u].pop()
                tree[v].remove(u)
                if len(tree[v]) == 1:
                    temp.append(v)
        leaf = temp
    
    # Count the remaining edges in the tree
    ans = 0
    for i in range(n):
        ans += len(tree[i])
    
    return ans

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [generate_tree_graph, generate_tree_graph]
    graph_labels = ["connected", "acyclic"]
    data = {label: {"graphs": [], "numNodes": [], "coins": [], "labels": [], "complexity": []} for label in graph_labels}
    
    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            G = graph_func(n)
            edges = list(G.edges())
            coins = [random.choice([0, 1]) for _ in range(n)]
            label_check = gen_label(coins, edges)
        

            data[label]["numNodes"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["coins"].append(coins)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(edges))  # Number of edges as a measure of complexity

    # Writing the data to a JSONL file
    with open(filename, 'w') as file:
        for item in data.items():
            file.write(json.dumps({item[0]: item[1]}))
            file.write('\n')

# Function call to generate the graph datasets and save them
generate_and_save_graphs(10, 1, 200, '../../../dataset/undirected/lc2603/sparse.jsonl')