from collections import defaultdict, deque
import math
from typing import List
import networkx as nx
import json
import random

def generate_connected_planar_graph(n):
    while True:
        G = nx.random_tree(n)
        additional_edges = int(0.1 * n)
        while additional_edges > 0:
            u, v = random.sample(range(n), 2)
            if not G.has_edge(u, v):
                G.add_edge(u, v)
                if nx.check_planarity(G)[0]:
                    additional_edges -= 1
                else:
                    G.remove_edge(u, v)
        if nx.check_planarity(G)[0]:
            return G

def generate_disconnected_planar_graph(n):
    while True:
        G = nx.Graph()
        G.add_nodes_from(range(n))
        parts = 2
        sizes = [n // parts + (1 if x < n % parts else 0) for x in range(parts)]
        start = 0
        for size in sizes:
            for i in range(start + 1, start + size):
                if random.random() < 0.1:
                    G.add_edge(i - 1, i)
            start += size
        if nx.check_planarity(G)[0]:
            return G

def generate_cyclic_planar_graph(n):
    while True:
        G = nx.cycle_graph(n)
        additional_edges = int(0.1 * n)
        while additional_edges > 0:
            u, v = random.sample(range(n), 2)
            if not G.has_edge(u, v):
                G.add_edge(u, v)
                if nx.check_planarity(G)[0]:
                    additional_edges -= 1
                else:
                    G.remove_edge(u, v)
        if nx.check_planarity(G)[0]:
            return G

def generate_acyclic_planar_graph(n):
    while True:
        G = nx.random_tree(n)
        if nx.check_planarity(G)[0]:
            return G

def gen_label(coins: List[int], edges: List[List[int]]) -> int:
    n = len(coins)
    tree = [set() for _ in range(n)]
    
    for e in edges:
        tree[e[0]].add(e[1])
        tree[e[1]].add(e[0])
    
    leaf = []
    for i in range(n):
        u = i
        while len(tree[u]) == 1 and coins[u] == 0:
            v = tree[u].pop()
            tree[v].remove(u)
            u = v
        if len(tree[u]) == 1:
            leaf.append(u)
    
    for sz in range(2, 0, -1):
        temp = []
        for u in leaf:
            if len(tree[u]) == 1:
                v = tree[u].pop()
                tree[v].remove(u)
                if len(tree[v]) == 1:
                    temp.append(v)
        leaf = temp
    
    ans = 0
    for i in range(n):
        ans += len(tree[i])
    
    return ans

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [generate_connected_planar_graph, generate_disconnected_planar_graph, generate_cyclic_planar_graph, generate_acyclic_planar_graph]
    graph_labels = ["connected", "disconnected", "cyclic", "acyclic"]
    data = {label: {"graphs": [], "numNodes": [], "coins": [], "labels": [], "complexity": []} for label in graph_labels}

    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            G = graph_func(n)
            edges = list(G.edges())
            coins = [random.choice([0, 1]) for _ in range(n)]
            label_check = gen_label(coins, edges)

            data[label]["numNodes"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["coins"].append(coins)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(edges))

    with open(filename, 'w') as file:
        for label in graph_labels:
            entry = json.dumps({label: data[label]})
            file.write(entry + '\n')

# Example usage
generate_and_save_graphs(10, 1, 200, '../../../dataset/undirected/lc2603/planar.jsonl')
