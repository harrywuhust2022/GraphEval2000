from functools import cache
import random
import json
import networkx as nx
from typing import *
from collections import defaultdict, deque


def connected_sparse_graph(n):
    G = nx.generators.trees.random_tree(n)
    return G


def acyclic_sparse_graph(n):
    G = nx.generators.trees.random_tree(n)
    return G


def gen_label(edges: List[List[int]], bob: int, amount: List[int]) -> int:
    graph = defaultdict(list)
    for a, b in edges:
        graph[a].append(b)
        graph[b].append(a)

    n = len(graph)
    pars = [None] * n
    chd = [0] * n

    leaves = []
    stk = deque([0])
    while stk:
        cur = stk.popleft()
        par = pars[cur]
        for nxt in graph[cur]:
            if nxt != par:
                pars[nxt] = cur
                chd[cur] += 1
                stk.append(nxt)
        if not chd[cur]:
            leaves.append(cur)

    cur = bob
    path = []
    while True:
        path.append(cur)
        if pars[cur] == None:
            break
        cur = pars[cur]

    m = len(path)
    for i in range(m // 2):
        amount[path[i]] = 0
    if m & 1:
        amount[path[m // 2]] //= 2

    @cache
    def dp(cur):
        res = amount[cur]
        par = pars[cur]
        if par == None:
            return res
        return res + dp(par)

    return max(dp(x) for x in leaves)


def generate_bob(n):
    # Randomly choose a node other than the root (node 0)
    return random.randint(1, n - 1)


def generate_amount(n):
    # Generate an array of even integers for amount
    return [random.choice(range(-int(10e4), int(10e4), 2)) for _ in range(n)]


def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [connected_sparse_graph, acyclic_sparse_graph]
    graph_labels = ["connected", "acyclic"]

    # Initialize the dictionary to store graph data
    data = {
        label: {
            "graphs": [],
            "numNodes": [],
            "labels": [],
            "complexity": [],
            "bob": [],
            "amount": [],
        }
        for label in graph_labels
    }

    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(
                min_n, max_n
            )  # Randomly choose the number of nodes within the given range
            G = graph_func(n)  # Generate the graph
            edges = list(G.edges())  # List of edges in the graph
            bob = generate_bob(n)  # Generate bob's position
            amount = generate_amount(n)  # Generate amount array
            label_check = gen_label(
                edges, bob, amount
            )  # Assuming Gen_label is a function to generate labels

            # Store graph information in the data dictionary
            data[label]["numNodes"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(
                len(edges)
            )  # Number of edges as a measure of complexity
            data[label]["bob"].append(bob)
            data[label]["amount"].append(amount)

    # Write the data to a jsonl file
    with open(filename, "w") as file:
        for label in graph_labels:
            entry = json.dumps({label: data[label]})
            file.write(entry + "\n")


# Example usage
generate_and_save_graphs(10, 20, 200, "../../../dataset/undirected/lc2467/planar.jsonl")
