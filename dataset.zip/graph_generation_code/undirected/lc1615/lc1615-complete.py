import networkx as nx
import random
import json
from typing import List

def connected_complete_graph(n):
    """Generate a connected complete graph with n nodes."""
    return nx.complete_graph(n)

def Gen_label(n: int, roads: List[List[int]]) -> int:
    g = [[False] * n for _ in range(n)]
    for x, y in roads:
        g[x][y] = g[y][x] = True

    ans = 0
    for i in range(n):
        for j in range(n):
            if i == j:
                continue

            cur = 0
            for k in range(n):
                if k != i and k != j:
                    if g[i][k]:
                        cur += 1

                    if g[j][k]:
                        cur += 1

            if g[i][j]:
                cur += 1

            ans = max(cur, ans)

    return ans

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    data = {"connected": {"graphs": [], "numCourse": [], "labels": [], "complexity": []}}
    
    for _ in range(num_graphs):
        n = random.randint(min_n, max_n)
        G = connected_complete_graph(n)
        edges = list(G.edges())
        label_check = Gen_label(n, edges)
        data["connected"]["numCourse"].append(n)
        data["connected"]["graphs"].append(edges)
        data["connected"]["labels"].append(label_check)
        data["connected"]["complexity"].append(len(edges))  # Number of edges as a measure of complexity

    with open(filename, 'w') as file:
        json_data = json.dumps(data)
        file.write(json_data)

# Parameters for graph generation
num_graphs = 10
min_n = 2
max_n = 100
filename = '../../../dataset/undirected/lc1615/complete.jsonl'

# Generate and save the graphs
generate_and_save_graphs(num_graphs, min_n, max_n, filename)