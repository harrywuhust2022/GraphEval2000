import networkx as nx
import random
import json
from typing import List

def connected_regular_graph(n, d):
    """Generate a connected d-regular graph with n nodes."""
    if n * d % 2 != 0 or d >= n:
        return None  # It's impossible to create such a regular graph
    return nx.random_regular_graph(d, n)

def disconnected_regular_graph(n, d):
    """Generate a disconnected regular graph with n nodes."""
    if n * d % 2 != 0 or d >= n:
        return None  # It's impossible to create such a regular graph because total nd must be even and degree less than n
    
    G = nx.Graph()
    components = []
    remaining_nodes = n
    
    while remaining_nodes > 0:
        # Choose a size for the next component that can feasibly form a d-regular graph
        if remaining_nodes == n:
            # First component, ensure it's possible to form a d-regular graph
            size = random.choice([k for k in range(d+1, remaining_nodes+1) if k * d % 2 == 0])
        else:
            # Subsequent components, be mindful of remaining nodes
            possible_sizes = [k for k in range(d+1, remaining_nodes+1) if k * d % 2 == 0]
            if not possible_sizes:
                break  # No valid sizes for a new component
            size = random.choice(possible_sizes)
        
        if size * d % 2 == 0 and size >= d:
            try:
                component = nx.random_regular_graph(d, size)
                nx.relabel_nodes(component, dict(enumerate(range(n - remaining_nodes, n - remaining_nodes + size))), copy=False)
                G = nx.disjoint_union(G, component)
                remaining_nodes -= size
            except nx.NetworkXError:
                # Fallback if graph generation fails, typically due to d being too large for the size
                continue
        else:
            break  # Break if we cannot form a new component

    return G

def cyclic_regular_graph(n, d):
    """Generate a cyclic regular graph with n nodes."""
    # Ensuring the regular graph contains cycles
    if n * d % 2 != 0 or d == 2 and n % 2 != 0:
        return None
    return nx.random_regular_graph(d, n)

def Gen_label(n: int, roads: List[List[int]]) -> int:
    g = [[False] * n for _ in range(n)]
    for x, y in roads:
        g[x][y] = g[y][x] = True

    ans = 0
    for i in range(n):
        for j in range(n):
            if i == j:
                continue

            cur = 0
            for k in range(n):
                if k != i and k != j:
                    if g[i][k]:
                        cur += 1

                    if g[j][k]:
                        cur += 1

            if g[i][j]:
                cur += 1

            ans = max(cur, ans)

    return ans

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [connected_regular_graph, disconnected_regular_graph, cyclic_regular_graph]
    graph_labels = ["connected", "disconnected", "cyclic"]
    data = {label: {"graphs": [], "numCourse": [], "labels": [], "complexity": []} for label in graph_labels}
    
    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            valid = False
            while not valid:
                n = random.randint(min_n, max_n)
                d = random.randint(2, max(n // 2, 2))  # Regular degree
                G = graph_func(n, d)
                if G:
                    valid = True
                    edges = list(G.edges())
                    label_check = Gen_label(n, edges)
                    data[label]["numCourse"].append(n)
                    data[label]["graphs"].append(edges)
                    data[label]["labels"].append(label_check)
                    data[label]["complexity"].append(len(edges))
    
    with open(filename, 'w') as file:
        for key, value in data.items():
            file.write(json.dumps({key: value}) + '\n')

# Parameters for graph generation
num_graphs = 10
min_n = 2
max_n = 100
filename = '../../../dataset/undirected/lc1615/regular.jsonl'

# Generate and save the graphs
generate_and_save_graphs(num_graphs, min_n, max_n, filename)
