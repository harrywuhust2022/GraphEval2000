import networkx as nx
import random
import json
from typing import List


def connected_planar_graph(n):
    """Generate a connected planar graph with n nodes."""
    while True:
        G = nx.generators.random_tree(n)
        add_extra_edges(G, n)
        if nx.check_planarity(G)[0]:
            return G


def disconnected_planar_graph(n):
    """Generate a disconnected planar graph with n nodes."""
    while True:
        G = nx.Graph()
        components = random.randint(2, max(3, n // 50))  # at least 2 components
        sizes = random_partition(n, components)
        start = 0
        for size in sizes:
            component = nx.generators.random_tree(size)
            mapping = {i: i + start for i in range(size)}
            G = nx.union(G, nx.relabel_nodes(component, mapping))
            start += size
        if nx.check_planarity(G)[0]:
            return G


def cyclic_planar_graph(n):
    """Generate a cyclic planar graph with n nodes."""
    while True:
        G = nx.generators.cycle_graph(n)
        add_extra_edges(G, n)
        if nx.check_planarity(G)[0]:
            return G


def acyclic_planar_graph(n):
    """Generate an acyclic planar graph with n nodes, which is a tree."""
    while True:
        G = nx.generators.random_tree(n)
        if nx.check_planarity(G)[0]:
            return G


def add_extra_edges(G, n):
    """Add random extra edges to ensure sparsity but still more complex than a tree."""
    extra_edges = random.randint(0, n // 10)  # sparsely adding extra edges
    while extra_edges > 0:
        u = random.randint(0, n - 1)
        v = random.randint(0, n - 1)
        if u != v and not G.has_edge(u, v):
            G.add_edge(u, v)
            extra_edges -= 1


def random_partition(total, parts):
    """Partition total into 'parts' parts randomly."""
    avg = total / parts
    deviations = [random.randint(-avg // 2, avg // 2) for _ in range(parts)]
    partition = [int(avg + dev) for dev in deviations]
    difference = total - sum(partition)
    partition[random.randint(0, parts - 1)] += difference
    return partition


def Gen_label(n: int, roads: List[List[int]]) -> int:
    g = [[False] * n for _ in range(n)]
    for x, y in roads:
        g[x][y] = g[y][x] = True

    ans = 0
    for i in range(n):
        for j in range(n):
            if i == j:
                continue

            cur = 0
            for k in range(n):
                if k != i and k != j:
                    if g[i][k]:
                        cur += 1

                    if g[j][k]:
                        cur += 1

            if g[i][j]:
                cur += 1

            ans = max(cur, ans)

    return ans


def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [
        connected_planar_graph,
        disconnected_planar_graph,
        cyclic_planar_graph,
        acyclic_planar_graph,
    ]
    graph_labels = ["connected", "disconnected", "cyclic", "acyclic"]
    data = {
        label: {"graphs": [], "numCourse": [], "labels": [], "complexity": []}
        for label in graph_labels
    }

    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            G = graph_func(n)
            edges = list(G.edges())
            label_check = Gen_label(n, edges)
            data[label]["numCourse"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(
                len(edges)
            )  # Number of edges as a measure of complexity

    with open(filename, "w") as file:
        for key, value in data.items():
            file.write(json.dumps({key: value}) + "\n")


# Parameters for graph generation
num_graphs = 10
min_n = 2
max_n = 100
filename = "../../../dataset/undirected/lc1615/planar.jsonl"

# Generate and save the graphs
generate_and_save_graphs(num_graphs, min_n, max_n, filename)
