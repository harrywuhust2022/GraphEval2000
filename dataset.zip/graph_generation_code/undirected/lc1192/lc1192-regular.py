import networkx as nx
import random
import json
from typing import List

def generate_connected_regular_graph(n, degree=3):
    if degree * n % 2 != 0 or degree >= n:
        return None
    try:
        G = nx.random_regular_graph(degree, n)
        if nx.is_connected(G):
            return G
    except nx.NetworkXError:
        return None
    return None

def generate_cyclic_regular_graph(n, degree=3):
    if degree * n % 2 != 0 or degree >= n:
        return None
    try:
        G = nx.random_regular_graph(degree, n)
        if any(len(cycle) > 2 for cycle in nx.cycle_basis(G)):
            return G
    except nx.NetworkXError:
        return None
    return None

def gen_label(n: int, connections: List[List[int]]) -> List[List[int]]:
        
        # node is index, neighbors are in the list
        graph = [[] for i in range(n)]
        
        # build graph
        for n1, n2 in connections:
            graph[n1].append(n2)
            graph[n2].append(n1)
        
        # min_discovery_time of nodes at respective indices from start node
        # 1. default to max which is the depth of continuous graph
        lows = [n] * n
        
        # critical edges 
        critical = []
        
        # args: node, node discovery_time in dfs, parent of this node
        def dfs(node, discovery_time, parent):
            
            # if the low is not yet discovered for this node
            if lows[node] == n:
                
                # 2. default it to the depth or discovery time of this node
                lows[node] = discovery_time
                
                # iterate over neighbors
                for neighbor in graph[node]:
                    
                    # all neighbors except parent
                    if neighbor != parent:
                        
                        expected_discovery_time_of_child = discovery_time + 1
                        actual_discovery_time_of_child = dfs(neighbor, expected_discovery_time_of_child, node)
                        
                        # nothing wrong - parent got what was expected => no back path
                        # this step is skipped if there is a back path
                        if actual_discovery_time_of_child >= expected_discovery_time_of_child:
                            critical.append((node, neighbor))
                        
                        # low will be equal to discovery time of this node or discovery time of child
                        # whichever one is minm
                        # if its discovery time of child - then there is a backpath
                        lows[node] = min(lows[node], actual_discovery_time_of_child)
                        

            # return low of this node discovered previously or during this call 
            return lows[node]
        
        dfs(n-1, 0, -1)
        
        return critical

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [generate_connected_regular_graph, generate_cyclic_regular_graph]
    graph_labels = ["connected", "cyclic"]
    data = {label: {"graphs": [], "numCourse": [], "labels": [], "complexity": []} for label in graph_labels}
    
    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            G = graph_func(n)
            if G is None:
                continue
            edges = list(G.edges())
            label_check = gen_label(n, edges)
            data[label]["numCourse"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(edges))  # Number of edges as a measure of complexity

    with open(filename, 'w') as file:
        for label, contents in data.items():
            file.write(json.dumps({label: contents}) + '\n')

# Example usage
generate_and_save_graphs(10, 20, 200, '../../../dataset/undirected/lc1192/regular.jsonl')