from typing import List
import networkx as nx
import random
import json

def generate_connected_sparse_graph(n: int) -> nx.Graph:
    G = nx.random_tree(n)
    extra_edges = max(0, int(n / 10))
    while extra_edges > 0:
        u, v = random.sample(range(n), 2)
        if not G.has_edge(u, v):
            G.add_edge(u, v)
            extra_edges -= 1
    return G

### PROBLEM DOESN'T ALLOW DISCONNECTED
# def generate_disconnected_sparse_graph(n: int) -> nx.Graph:
#     G = nx.Graph()
#     components = random.randint(2, max(3, n // 50))
#     sizes = [random.randint(1, n - sum(sizes) - (components - i - 1)) for i in range(components - 1)]
#     sizes.append(n - sum(sizes))
#     start = 0
#     for size in sizes:
#         subtree = nx.random_tree(size)
#         mapping = {i: i + start for i in range(size)}
#         G = nx.union(G, nx.relabel_nodes(subtree, mapping))
#         start += size
#     return G

def generate_cyclic_sparse_graph(n: int) -> nx.Graph:
    G = generate_connected_sparse_graph(n)
    if n > 2:
        cycle = random.sample(range(n), random.randint(3, min(n, 10)))
        nx.add_cycle(G, cycle)
    return G

def generate_acyclic_sparse_graph(n: int) -> nx.Graph:
    G = nx.Graph()
    # Decide the number of components
    components = random.randint(1, max(2, n // 50))
    remaining_nodes = n
    start = 0
    
    for i in range(components - 1):
        if remaining_nodes <= 2:  # Avoid having 0 or 1 node in the last component
            break
        size = random.randint(1, remaining_nodes - (components - i))
        subtree = nx.random_tree(size)
        mapping = {j: j + start for j in range(size)}
        G = nx.union(G, nx.relabel_nodes(subtree, mapping))
        start += size
        remaining_nodes -= size
    
    # Add the last component with the remaining nodes
    if remaining_nodes > 0:
        subtree = nx.random_tree(remaining_nodes)
        mapping = {j: j + start for j in range(remaining_nodes)}
        G = nx.union(G, nx.relabel_nodes(subtree, mapping))
    
    return G


def gen_label(n: int, connections: List[List[int]]) -> List[List[int]]:
        
        # node is index, neighbors are in the list
        graph = [[] for i in range(n)]
        
        # build graph
        for n1, n2 in connections:
            graph[n1].append(n2)
            graph[n2].append(n1)
        
        # min_discovery_time of nodes at respective indices from start node
        # 1. default to max which is the depth of continuous graph
        lows = [n] * n
        
        # critical edges 
        critical = []
        
        # args: node, node discovery_time in dfs, parent of this node
        def dfs(node, discovery_time, parent):
            
            # if the low is not yet discovered for this node
            if lows[node] == n:
                
                # 2. default it to the depth or discovery time of this node
                lows[node] = discovery_time
                
                # iterate over neighbors
                for neighbor in graph[node]:
                    
                    # all neighbors except parent
                    if neighbor != parent:
                        
                        expected_discovery_time_of_child = discovery_time + 1
                        actual_discovery_time_of_child = dfs(neighbor, expected_discovery_time_of_child, node)
                        
                        # nothing wrong - parent got what was expected => no back path
                        # this step is skipped if there is a back path
                        if actual_discovery_time_of_child >= expected_discovery_time_of_child:
                            critical.append((node, neighbor))
                        
                        # low will be equal to discovery time of this node or discovery time of child
                        # whichever one is minm
                        # if its discovery time of child - then there is a backpath
                        lows[node] = min(lows[node], actual_discovery_time_of_child)
                        

            # return low of this node discovered previously or during this call 
            return lows[node]
        
        dfs(n-1, 0, -1)
        
        return critical

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_funcs = [
        generate_connected_sparse_graph,
        # generate_disconnected_sparse_graph,
        generate_cyclic_sparse_graph,
        generate_acyclic_sparse_graph
    ]
    # graph_labels = ["connected", "disconnected", "cyclic", "acyclic"]
    graph_labels = ["connected", "cyclic", "acyclic"]
    data = {label: {"graphs": [], "n_list": [], "labels": [], "complexity": []} for label in graph_labels}
    
    for graph_func, label in zip(graph_funcs, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            G = graph_func(n)
            edges = list(G.edges())
            label_check = gen_label(n, edges)
            data[label]["n_list"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(edges))  # Number of edges as a measure of complexity

    with open(filename, 'w') as file:
        for label, content in data.items():
            entry = json.dumps({label: content})
            file.write(entry + '\n')

# Example usage
generate_and_save_graphs(10, 20, 200, 'sparse.jsonl')