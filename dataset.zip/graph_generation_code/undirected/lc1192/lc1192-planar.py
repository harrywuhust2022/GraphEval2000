import networkx as nx
import random
import json
from typing import *

def generate_connected_planar_graph(n: int) -> nx.Graph:
    while True:
        G = nx.random_tree(n)
        extra_edges = max(0, int(n / 10))
        while extra_edges > 0:
            u, v = random.sample(range(n), 2)
            if not G.has_edge(u, v):
                G.add_edge(u, v)
                extra_edges -= 1
        if nx.check_planarity(G)[0]:
            return G

def generate_cyclic_planar_graph(n: int) -> nx.Graph:
    while True:
        G = generate_connected_planar_graph(n)
        if n > 2:
            cycle = random.sample(range(n), random.randint(3, min(n, 10)))
            nx.add_cycle(G, cycle)
        if nx.check_planarity(G)[0]:
            return G

def generate_acyclic_planar_graph(n: int) -> nx.Graph:
    while True:
        G = nx.Graph()
        components = random.randint(1, max(2, n // 50))
        remaining_nodes = n
        start = 0

        for i in range(components - 1):
            if remaining_nodes <= 2:
                break
            size = random.randint(1, remaining_nodes - (components - i))
            subtree = nx.random_tree(size)
            mapping = {j: j + start for j in range(size)}
            G = nx.union(G, nx.relabel_nodes(subtree, mapping))
            start += size
            remaining_nodes -= size

        if remaining_nodes > 0:
            subtree = nx.random_tree(remaining_nodes)
            mapping = {j: j + start for j in range(remaining_nodes)}
            G = nx.union(G, nx.relabel_nodes(subtree, mapping))

        if nx.check_planarity(G)[0]:
            return G

def gen_label(n: int, connections: List[List[int]]) -> List[List[int]]:
    graph = [[] for i in range(n)]
    for n1, n2 in connections:
        graph[n1].append(n2)
        graph[n2].append(n1)

    lows = [n] * n
    critical = []

    def dfs(node, discovery_time, parent):
        if lows[node] == n:
            lows[node] = discovery_time
            for neighbor in graph[node]:
                if neighbor != parent:
                    expected_discovery_time_of_child = discovery_time + 1
                    actual_discovery_time_of_child = dfs(neighbor, expected_discovery_time_of_child, node)
                    if actual_discovery_time_of_child >= expected_discovery_time_of_child:
                        critical.append((node, neighbor))
                    lows[node] = min(lows[node], actual_discovery_time_of_child)
        return lows[node]

    dfs(n-1, 0, -1)
    return critical

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_funcs = [
        generate_connected_planar_graph,
        generate_cyclic_planar_graph,
        generate_acyclic_planar_graph
    ]
    graph_labels = ["connected", "cyclic", "acyclic"]
    data = {label: {"graphs": [], "n_list": [], "labels": [], "complexity": []} for label in graph_labels}

    for graph_func, label in zip(graph_funcs, graph_labels):
        for _ in range(num_graphs):
            print(label)
            n = random.randint(min_n, max_n)
            G = graph_func(n)
            edges = list(G.edges())
            label_check = gen_label(n, edges)
            data[label]["n_list"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(edges))

    with open(filename, 'w') as file:
        for label, content in data.items():
            entry = json.dumps({label: content})
            file.write(entry + '\n')

# Example usage
generate_and_save_graphs(10, 20, 100, '../../../dataset/undirected/lc1192/planar.jsonl')
