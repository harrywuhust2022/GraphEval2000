from collections import defaultdict, deque
import math
from typing import List
import networkx as nx
import json
import random

def generate_connected_planar_tree(n):
    while True:
        G = nx.random_tree(n, seed=random.randint(1, 1000))
        if nx.check_planarity(G)[0]:
            return G

def generate_acyclic_planar_tree(n):
    while True:
        G = nx.random_tree(n, seed=random.randint(1, 1000))
        if nx.check_planarity(G)[0]:
            return G

def gen_label(roads: List[List[int]], seats: int) -> int:
    adjacency_list = defaultdict(list)
    for a, b in roads:
        adjacency_list[a].append(b)
        adjacency_list[b].append(a)
    total_fuel_cost = [0]
    def dfs(node, parent):
        people = 1
        for neighbor in adjacency_list[node]:
            if neighbor == parent:
                continue
            people += dfs(neighbor, node)
        if node != 0:
            total_fuel_cost[0] += math.ceil(people / seats)
        return people
    dfs(0, None)
    return total_fuel_cost[0]

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [generate_connected_planar_tree, generate_acyclic_planar_tree]
    graph_labels = ["connected", "acyclic"]
    data = {label: {"graphs": [], "numNodes": [], "seats": [], "labels": [], "complexity": []} for label in graph_labels}

    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            G = graph_func(n)
            edges = list(G.edges())
            seat = random.randint(1, 100000)
            label_check = gen_label(edges, seat)

            data[label]["numNodes"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["seats"].append(seat)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(edges))

    # Writing the data to a JSONL file
    with open(filename, 'w') as file:
        for item in data.items():
            file.write(json.dumps({item[0]: item[1]}))
            file.write('\n')

# Function call to generate the graph datasets and save them
generate_and_save_graphs(10, 20, 200, '../../../dataset/undirected/lc2477/planar.jsonl')
