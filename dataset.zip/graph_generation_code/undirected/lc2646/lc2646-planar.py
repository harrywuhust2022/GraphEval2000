from collections import defaultdict, deque
import math
from typing import List
import networkx as nx
import json
import random

def generate_connected_planar_tree(n):
    while True:
        G = nx.random_tree(n, seed=random.randint(1, 1000))
        if nx.check_planarity(G)[0]:
            return G

def generate_acyclic_planar_tree(n):
    while True:
        G = nx.random_tree(n, seed=random.randint(1, 1000))
        if nx.check_planarity(G)[0]:
            return G

def generate_trips(n):
    """
    Generate a list of trips for n nodes, with a random number of trips between 1 and 100.
    """
    num_trips = random.randint(1, 100)  # Randomly choose the number of trips between 1 and 100
    trips = []
    for _ in range(num_trips):
        starti = random.randint(0, n - 1)
        endi = random.randint(0, n - 1)
        trips.append([starti, endi])
    return trips

def gen_label(n: int, edges: List[List[int]], price: List[int], trips: List[List[int]]) -> int:
    g = [[] for _ in range(n)]
    for i, j in edges:
        g[i].append(j)
        g[j].append(i)
        
    freq = [0] * n
    level = [0] * n
    parent = [0] * n
    
    def dfs(i, l, p):
        level[i] = l
        parent[i] = p
        for j in g[i]:
            if j != p:
                dfs(j, l + 1, i)
    
    def LCA(a, b):
        if level[a] > level[b]:
            a, b = b, a
        d = level[b] - level[a]
        while d:
            b = parent[b]
            d -= 1
        if a == b:
            return a
        while a != b:
            a = parent[a]
            b = parent[b]
        return a
    
    dfs(0, 0, -1)
    for i, j in trips:
        lca = LCA(i, j)
        while i != lca:
            freq[i] += 1
            i = parent[i]
        freq[i] += 1
        while j != lca:
            freq[j] += 1
            j = parent[j]
    
    def dp(i, p):
        res0 = 0
        res1 = price[i] // 2 * freq[i]
        for j in g[i]:
            if j != p:
                curr = dp(j, i)
                res0 += max(curr)
                res1 += curr[0]
        return [res0, res1]
    
    ans = 0
    for i in range(n):
        ans += freq[i] * price[i]
    return ans - max(dp(0, -1))

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [generate_connected_planar_tree, generate_acyclic_planar_tree]
    graph_labels = ["connected", "acyclic"]
    data = {label: {"graphs": [], "numNodes": [], "price": [], "trips": [], "labels": [], "complexity": []} for label in graph_labels}

    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            G = graph_func(n)
            edges = list(G.edges())
            price = [random.randint(0, 1000) for _ in range(n)]
            trip = generate_trips(n)

            label_check = gen_label(n, edges, price, trip)

            data[label]["numNodes"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["price"].append(price)
            data[label]["trips"].append(trip)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(edges))  # Number of edges as a measure of complexity

    # Writing the data to a JSONL file
    with open(filename, 'w') as file:
        for item in data.items():
            file.write(json.dumps({item[0]: item[1]}))
            file.write('\n')

# Function call to generate the graph datasets and save them
generate_and_save_graphs(10, 1, 50, '../../../dataset/undirected/lc2646/planar.jsonl')
