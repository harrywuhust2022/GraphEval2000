import networkx as nx
import random
import string
import json
from heapq import nlargest

def generate_connected_planar_graph(n):
    while True:
        G = nx.random_tree(n, seed=random.randint(1, 100))
        parent = [-1] + [list(G.neighbors(i))[0] for i in range(1, n)]
        additional_edges = min(n, max(5, n // 10))
        while additional_edges > 0:
            u, v = random.sample(range(n), 2)
            if not G.has_edge(u, v):
                G.add_edge(u, v)
                if nx.check_planarity(G)[0]:
                    additional_edges -= 1
                else:
                    G.remove_edge(u, v)
        if nx.check_planarity(G)[0]:
            return G, parent

def generate_disconnected_planar_graph(n):
    while True:
        components = random.randint(2, max(2, n // 20))
        G = nx.Graph()
        parent = [-1] * n
        start = 0
        for i in range(components):
            size = n // components + (1 if i < n % components else 0)
            T = nx.random_tree(size, seed=random.randint(1, 100))
            mapping = {k: v + start for k, v in enumerate(T.nodes())}
            T = nx.relabel_nodes(T, mapping)
            G = nx.compose(G, T)
            if i == 0:
                parent[start] = -1
            for j in range(1, size):
                parent[start + j] = list(T.neighbors(start + j))[0]
            start += size
        if nx.check_planarity(G)[0]:
            return G, parent

def generate_cyclic_planar_graph(n):
    while True:
        G = nx.random_tree(n, seed=random.randint(1, 100))
        parent = [-1] + [list(G.neighbors(i))[0] for i in range(1, n)]
        u, v = random.sample(range(n), 2)
        G.add_edge(u, v)
        additional_edges = min(n, max(3, n // 15))
        while additional_edges > 0:
            u, v = random.sample(range(n), 2)
            if not G.has_edge(u, v):
                G.add_edge(u, v)
                if nx.check_planarity(G)[0]:
                    additional_edges -= 1
                else:
                    G.remove_edge(u, v)
        if nx.check_planarity(G)[0]:
            return G, parent

def generate_acyclic_planar_graph(n):
    while True:
        G = nx.random_tree(n, seed=random.randint(1, 100))
        parent = [-1] + [list(G.neighbors(i))[0] for i in range(1, n)]
        if nx.check_planarity(G)[0]:
            return G, parent

def Gen_label(parent, s):
    children = [[] for _ in range(len(s))]
    for i, j in enumerate(parent):
        if j >= 0:
            children[j].append(i)
    
    res = [0]
    def dfs(i):
        candi = [0]
        for j in children[i]:
            cur = dfs(j)
            if s[i] != s[j]:
                candi.append(cur)
                
        candi = nlargest(2, candi)
        res[0] = max(res[0], sum(candi) + 1)
        return max(candi) + 1
    
    dfs(0)
    return res[0]

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [generate_connected_planar_graph, generate_disconnected_planar_graph, generate_cyclic_planar_graph, generate_acyclic_planar_graph]
    graph_labels = ["connected", "disconnected", "cyclic", "acyclic"]
    data = {label: {"graphs": [], "n": [], "s": [], "label": [], "complexity": []} for label in graph_labels}

    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            G, parent = graph_func(n)
            s = ''.join(random.choices(string.ascii_lowercase, k=n))  # Generate labels
            label_check = Gen_label(parent, s)
            complexity = len(G.edges())
            data[label]["graphs"].append(parent)
            data[label]["n"].append(n)
            data[label]["s"].append(s)
            data[label]["label"].append(label_check)
            data[label]["complexity"].append(complexity)

    with open(filename, 'w') as file:
        json.dump(data, file)

# Example usage
generate_and_save_graphs(10, 20, 200, '../../../dataset/undirected/lc2246/planar.jsonl')
