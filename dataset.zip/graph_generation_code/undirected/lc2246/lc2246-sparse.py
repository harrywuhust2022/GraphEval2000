import networkx as nx
import random
import string
import json
from heapq import nlargest

def generate_connected_sparse_graph(n):
    G = nx.random_tree(n, seed=random.randint(1, 100))
    parent = [-1] + [list(G.neighbors(i))[0] for i in range(1, n)]
    return G, parent

def generate_disconnected_sparse_graph(n):
    components = random.randint(2, max(2, n // 20))
    G = nx.Graph()
    parent = [-1] * n
    start = 0
    for i in range(components):
        size = n // components + (1 if i < n % components else 0)
        T = nx.random_tree(size, seed=random.randint(1, 100))
        mapping = {k: v + start for k, v in enumerate(T.nodes())}
        T = nx.relabel_nodes(T, mapping)
        G = nx.compose(G, T)
        # Update the parent array for each component
        if i == 0:
            parent[start] = -1
        for j in range(1, size):
            parent[start + j] = list(T.neighbors(start + j))[0]
        start += size
    return G, parent

def generate_cyclic_sparse_graph(n):
    G = nx.random_tree(n, seed=random.randint(1, 100))
    parent = [-1] + [list(G.neighbors(i))[0] for i in range(1, n)]
    # Add a cycle
    u, v = random.sample(range(n), 2)
    G.add_edge(u, v)
    return G, parent

def Gen_label(parent, s):
    children = [[] for i in range(len(s))]
    for i,j in enumerate(parent):
        if j >= 0:
            children[j].append(i)
    
    res = [0]
    def dfs(i):
        candi = [0]
        for j in children[i]:
            cur = dfs(j)
            if s[i] != s[j]:
                candi.append(cur)
                
        candi = nlargest(2, candi)
        res[0] = max(res[0], sum(candi) + 1)
        return max(candi) + 1
    
    dfs(0)
    return res[0]

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [generate_connected_sparse_graph, generate_disconnected_sparse_graph, generate_cyclic_sparse_graph]
    graph_labels = ["connected", "disconnected", "cyclic"]
    data = {label: {"graphs": [], "n": [], "s": [], "label": [], "complexity": []} for label in graph_labels}

    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            G, parent = graph_func(n)
            s = ''.join(random.choices(string.ascii_lowercase, k=n))  # Generate labels
            label_check = Gen_label(parent, s)  # Placeholder for your Gen_label function
            complexity = len(G.edges())
            data[label]["graphs"].append(parent)
            data[label]["n"].append(n)
            data[label]["s"].append(s)
            data[label]["label"].append(label_check)
            data[label]["complexity"].append(complexity)

    with open(filename, 'w') as file:
        json.dump(data, file)  # Ensure proper JSON formatting

# Example call to the function
generate_and_save_graphs(10, 20, 200, '../../../dataset/undirected/lc2246/sparse.jsonl')



