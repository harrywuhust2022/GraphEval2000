from collections import defaultdict, deque
from itertools import accumulate, chain, product
from typing import Counter, List
import networkx as nx
import random
import json

def connected_planar_graph(n):
    while True:
        G = nx.random_tree(n)
        additional_edges = min(n, max(5, n // 10))
        while additional_edges > 0:
            u, v = random.sample(range(n), 2)
            if not G.has_edge(u, v):
                G.add_edge(u, v)
                additional_edges -= 1
        if nx.check_planarity(G)[0]:
            return G

def disconnected_planar_graph(n):
    while True:
        G = nx.Graph()
        G.add_nodes_from(range(n))
        start = 0
        while start < n:
            if n - start == 1:
                break
            component_size = random.randint(2, min(20, n - start))
            if n - start - component_size < 2:
                component_size = n - start
            H = nx.random_tree(component_size)
            mapping = {i: i + start for i in range(component_size)}
            H = nx.relabel_nodes(H, mapping)
            G = nx.compose(G, H)
            start += component_size
        if nx.check_planarity(G)[0]:
            return G

def cyclic_planar_graph(n):
    while True:
        G = nx.cycle_graph(n)
        additional_edges = min(n, max(3, n // 15))
        while additional_edges > 0:
            u, v = random.sample(range(n), 2)
            if not G.has_edge(u, v):
                G.add_edge(u, v)
                additional_edges -= 1
        if nx.check_planarity(G)[0]:
            return G

def acyclic_planar_graph(n):
    while True:
        G = nx.random_tree(n)
        if nx.check_planarity(G)[0]:
            return G

def gen_label(n: int, edges: List[List[int]]) -> int:
    graph = [[] for _ in range(n)]
    for x, y in edges:
        graph[x].append(y)
        graph[y].append(x)
    
    res = 0
    visited = [0 for _ in range(n)]
    dq = deque()
    for i in range(n):
        if visited[i] == 0:
            dq.append(i)
            visited[i] = 1
            curCount = 1
            while dq:
                v = dq.popleft()
                for neib in graph[v]:
                    if visited[neib] == 0:
                        curCount += 1
                        visited[neib] = 1
                        dq.append(neib)
            res += curCount * (n - curCount)
    return res // 2

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [connected_planar_graph, disconnected_planar_graph, cyclic_planar_graph, acyclic_planar_graph]
    graph_labels = ["connected", "disconnected", "cyclic", "acyclic"]
    
    data = {label: {"graphs": [], "numNodes": [], "labels": [], "complexity": []} for label in graph_labels}
    
    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            G = graph_func(n)
            edges = list(G.edges())
            label_check = gen_label(n, edges)
            data[label]["numNodes"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(edges))

    with open(filename, 'w') as file:
        for label in graph_labels:
            entry = json.dumps({label: data[label]})
            file.write(entry + '\n')

# Example usage
generate_and_save_graphs(10, 5, 50, '../../../dataset/undirected/lc2316/planar.jsonl')
