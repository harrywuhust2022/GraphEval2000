from collections import defaultdict, deque
from typing import List
import networkx as nx
import random
import json

def connected_complete_graph(n):
    """Generate a complete graph with n nodes."""
    G = nx.complete_graph(n)
    return G

def gen_label(n: int, edges: List[List[int]]) -> int:
        # We find the nodes in the present connected component
        # that means all the other nodes that are not connected are
        # notconnectednodes = n-connectedNodes
        # therefores required pairs = (connectedNodes)*(n-connectedNodes)
        # since we will count a pair twice once from each end we divide with 2 

        graph = [ [] for _ in range(0,n) ]
        for x,y in edges:
            graph[x].append(y)
            graph[y].append(x)
        
        res = 0
        visited = [0 for _ in range(0,n)]
        dq = deque()
        for i in range(0,n):
            if(visited[i]==0):
                dq.append(i);
                visited[i] = 1
                curCount = 1
                while(len(dq)>0):
                    v = dq.popleft()
                    for neib in graph[v]:
                        if(visited[neib]== 0 ):
                            curCount += 1
                            visited[neib]=1
                            dq.append(neib)
                res+= curCount*(n-curCount)
        return res//2

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [connected_complete_graph]
    graph_labels = ["connected"]
    
    # Initialize the dictionary to store graph data
    data = {label: {"graphs": [], "numNodes": [], "labels": [], "complexity": []} for label in graph_labels}
    
    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)  # Randomly choose the number of nodes within the given range
            G = graph_func(n)  # Generate the graph
            edges = list(G.edges())  # List of edges in the graph
            label_check = gen_label(n, edges)  # Assuming Gen_label is a function to generate labels
            
            # Store graph information in the data dictionary
            data[label]["numNodes"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(edges))  # Number of edges as a measure of complexity
    
    # Write the data to a jsonl file
    with open(filename, 'w') as file:
        for label in graph_labels:
            entry = json.dumps({label: data[label]})
            file.write(entry + '\n')

# Example usage
generate_and_save_graphs(10, 5, 50, '../../../dataset/undirected/lc2316/complete.jsonl')