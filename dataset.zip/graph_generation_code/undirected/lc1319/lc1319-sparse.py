import networkx as nx
import random
import json
from typing import List

def disconnected_sparse_graph(n):
    G = nx.Graph()
    G.add_nodes_from(range(n))
    components = random.randint(2, max(2, n // 10))  # Random number of components
    start = 0
    for i in range(components):
        end = start + random.randint(1, (n - start) // (components - i))
        if i == components - 1:
            end = n
        tree = nx.generators.random_tree(end - start)
        relabeled_tree = nx.relabel_nodes(tree, {k: k + start for k in tree.nodes()})
        G = nx.compose(G, relabeled_tree)
        start = end
    return G

def cyclic_disconnected_sparse_graph(n):
    G = disconnected_sparse_graph(n)
    components = list(nx.connected_components(G))
    for component in components:
        if len(component) > 2 and random.random() > 0.5:  # Randomly add a cycle to some components
            cycle_nodes = random.sample(component, 3)
            G.add_edge(cycle_nodes[0], cycle_nodes[1])
            G.add_edge(cycle_nodes[1], cycle_nodes[2])
            G.add_edge(cycle_nodes[2], cycle_nodes[0])
    return G

def acyclic_disconnected_sparse_graph(n):
    return disconnected_sparse_graph(n)  # The base function already generates a forest

def Gen_label(n: int, connections: List[List[int]]) -> int:
        count = 0           # number of redundant connections
        network = [i for i in range(n)]

        def find(x):
            if network[x] != x:
                network[x] = find(network[x])
            return network[x]
        
        def union(a, b):
            # return True if 2 nodes are already connected.
            root_a = find(a)
            root_b = find(b)
            network[root_a] = root_b
            return True if root_a == root_b else False
        
        for link in connections:
            if union(link[0], link[1]):
                count += 1

        # count the number of connected clusters
        a = len(set([find(i) for i in range(n)]))
        return -1 if a - 1 > count else a - 1

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [disconnected_sparse_graph, cyclic_disconnected_sparse_graph, acyclic_disconnected_sparse_graph]
    graph_labels = ["disconnected", "cyclic", "acyclic"]
    data = {label: {"graphs": [], "numCourse": [], "labels": [], "complexity": []} for label in graph_labels}

    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            G = graph_func(n)
            edges = list(G.edges())
            label_check = Gen_label(n, edges)
            data[label]["numCourse"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["labels"].append(label_check)  # Assuming label as the type identifier
            data[label]["complexity"].append(len(edges))  # Number of edges as a measure of complexity

    with open(filename, 'w') as file:
        for label, content in data.items():
            record = {label: content}
            file.write(json.dumps(record) + '\n')

# Example usage
generate_and_save_graphs(10, 20, 200, '../../../dataset/undirected/lc1319/sparse.jsonl')
