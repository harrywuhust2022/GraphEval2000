import networkx as nx
import random
import json
from typing import List
import collections

def create_regular_graph(n, k, connected=True, cyclic=False):
    """Helper function to create a regular graph of degree k."""
    if n * k % 2 == 1:  # It's impossible to create a regular graph if n*k is odd
        return None
    try:
        if cyclic:
            return nx.random_regular_graph(k, n)
        elif connected:
            G = nx.random_regular_graph(k, n)
            while not nx.is_connected(G):
                G = nx.random_regular_graph(k, n)
            return G
        else:
            # Creating a disconnected graph by combining smaller regular graphs
            parts = [nx.random_regular_graph(k, p) for p in range(2, n) if p * k % 2 == 0]
            G = nx.disjoint_union_all(parts)
            if G.number_of_nodes() < n:  # Add isolated nodes if necessary
                G.add_nodes_from(range(G.number_of_nodes() + 1, n + 1))
            return G
    except:
        return None

def connected_regular_graph(n):
    """Generate a connected regular graph."""
    if n == 2:
        k = 1  # A single edge connecting the two nodes
    else:
        k = random.randint(2, min(n-1, 10))
    return create_regular_graph(n, k, connected=True)

def disconnected_regular_graph(n):
    """Generate a disconnected regular graph."""
    if n < 6:  # For very small graphs, a regular disconnected graph isn't feasible
        return None
    k = random.randint(2, min(n//2 - 1, 10))  # Adjust to ensure groups are possible
    try:
        # Attempt to create a disconnected graph by combining smaller regular graphs
        # Choose an arbitrary split point not in the middle to vary group sizes
        split_point = random.randint(2, n//2)
        group1 = max(split_point, k + 1)
        group2 = n - group1
        if group1 * k % 2 == 0 and group2 * k % 2 == 0:
            G1 = nx.random_regular_graph(k, group1)
            G2 = nx.random_regular_graph(k, group2)
            G = nx.disjoint_union(G1, G2)
            return G
        else:
            return None
    except:
        return None


def cyclic_regular_graph(n):
    """Generate a cyclic regular graph."""
    k = random.randint(2, min(n-1, 10))
    return create_regular_graph(n, k, cyclic=True)

def gen_label(n: int, edges: List[List[int]]) -> int:
        g = collections.defaultdict(set)
        for (a,b) in edges:
            g[a].add(b)
            g[b].add(a)
            
        d = collections.defaultdict(int)
        for n in g:
            d[n] = len(g[n])
            
        res = float('inf')
        for n in g:
            for m in g[n]:
                for o in g[n] & g[m]:
                    res = min(res, d[n]+d[m]+d[o]-6)
                    if n in g[o]:
                        g[o].remove(n)
                if n in g[m]:
                    g[m].remove(n)
        if res == float('inf'):
            return -1
        else:
            return res

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [connected_regular_graph, disconnected_regular_graph, cyclic_regular_graph]
    graph_labels = ["connected", "disconnected", "cyclic"]
    data = {label: {"graphs": [], "n_list": [], "labels": [], "complexity": []} for label in graph_labels}

    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            G = graph_func(n)
            while G is None:
                G = graph_func(n)
            edges = list(G.edges())
            label_check = gen_label(n, edges)
            data[label]["n_list"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(edges))  # Number of edges as a measure of complexity

    with open(filename, 'w') as file:
        for key, value in data.items():
            entry = json.dumps({key: value})
            file.write(entry + '\n')

generate_and_save_graphs(10, 2, 400, '../../../dataset/undirected/lc1761/regular.jsonl')
