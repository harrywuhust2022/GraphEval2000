import networkx as nx
import random
import json
from typing import List
import collections

def connected_complete_graph(n):
    """Generate a connected complete graph."""
    return nx.complete_graph(n)


def gen_label(n: int, edges: List[List[int]]) -> int:
        g = collections.defaultdict(set)
        for (a,b) in edges:
            g[a].add(b)
            g[b].add(a)
            
        d = collections.defaultdict(int)
        for n in g:
            d[n] = len(g[n])
            
        res = float('inf')
        for n in g:
            for m in g[n]:
                for o in g[n] & g[m]:
                    res = min(res, d[n]+d[m]+d[o]-6)
                    if n in g[o]:
                        g[o].remove(n)
                if n in g[m]:
                    g[m].remove(n)
        if res == float('inf'):
            return -1
        else:
            return res

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    data = {"connected": {"graphs": [], "n_list": [], "labels": [], "complexity": []}}
    graph_func = connected_complete_graph
    label = "connected"
    
    for _ in range(num_graphs):
        n = random.randint(min_n, max_n)
        G = graph_func(n)
        edges = list(G.edges())
        label_check = gen_label(n, edges)
        data[label]["n_list"].append(n)
        data[label]["graphs"].append(edges)
        data[label]["labels"].append(label_check)
        data[label]["complexity"].append(len(edges))  # Number of edges as a measure of complexity

    with open(filename, 'w') as file:
        json.dump(data, file)  # Use json.dump to write data directly as a single JSON object

generate_and_save_graphs(10, 2, 400, '../../../dataset/undirected/lc1761/complete.jsonl')
