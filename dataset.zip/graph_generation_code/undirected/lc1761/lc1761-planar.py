import networkx as nx
import random
import json
from typing import List
import collections

def connected_planar_graph(n):
    """Generate a connected planar graph."""
    while True:
        G = nx.Graph()
        G.add_nodes_from(range(1, n+1))
        # Ensure the graph is connected
        for i in range(1, n):
            G.add_edge(i, i + 1)
        # Add more edges randomly but keep it sparse
        additional_edges = n // 2
        while additional_edges > 0:
            u = random.randint(1, n)
            v = random.randint(1, n)
            if u != v and not G.has_edge(u, v):
                G.add_edge(u, v)
                additional_edges -= 1
        if nx.check_planarity(G)[0]:
            return G

def disconnected_planar_graph(n):
    """Generate a disconnected planar graph."""
    while True:
        G = nx.Graph()
        G.add_nodes_from(range(1, n+1))
        # Split nodes into two groups at least
        split_point = random.randint(1, n-1)
        # Connect first group
        for i in range(1, split_point):
            if random.random() > 0.5:  # Randomly decide to add an edge
                G.add_edge(i, i + 1)
        # Connect second group
        for i in range(split_point + 1, n):
            if random.random() > 0.5:  # Randomly decide to add an edge
                G.add_edge(i, i + 1)
        if nx.check_planarity(G)[0]:
            return G

def cyclic_planar_graph(n):
    """Generate a planar graph containing at least one cycle."""
    while True:
        G = nx.Graph()
        G.add_nodes_from(range(1, n+1))
        # Creating a cycle
        for i in range(1, n):
            G.add_edge(i, i + 1)
        G.add_edge(n, 1)  # Complete the cycle
        if nx.check_planarity(G)[0]:
            return G

def acyclic_planar_graph(n):
    """Generate an acyclic planar graph (tree)."""
    while True:
        G = nx.Graph()
        G.add_nodes_from(range(1, n+1))
        # Creating a tree
        for i in range(1, n):
            G.add_edge(i, i + 1)
        if nx.check_planarity(G)[0]:
            return G

def gen_label(n: int, edges: List[List[int]]) -> int:
    g = collections.defaultdict(set)
    for (a, b) in edges:
        g[a].add(b)
        g[b].add(a)

    d = collections.defaultdict(int)
    for n in g:
        d[n] = len(g[n])

    res = float('inf')
    for n in g:
        for m in g[n]:
            for o in g[n] & g[m]:
                res = min(res, d[n] + d[m] + d[o] - 6)
                if n in g[o]:
                    g[o].remove(n)
            if n in g[m]:
                g[m].remove(n)
    if res == float('inf'):
        return -1
    else:
        return res

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [connected_planar_graph, disconnected_planar_graph, cyclic_planar_graph, acyclic_planar_graph]
    graph_labels = ["connected", "disconnected", "cyclic", "acyclic"]
    data = {label: {"graphs": [], "n_list": [], "labels": [], "complexity": []} for label in graph_labels}

    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            G = graph_func(n)
            edges = list(G.edges())
            label_check = gen_label(n, edges)
            data[label]["n_list"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(edges))  # Number of edges as a measure of complexity

    with open(filename, 'w') as file:
        for key, value in data.items():
            entry = json.dumps({key: value})
            file.write(entry + '\n')

# Generate and save the graphs
generate_and_save_graphs(10, 2, 30, "../../../dataset/undirected/lc1761/planar.jsonl")
