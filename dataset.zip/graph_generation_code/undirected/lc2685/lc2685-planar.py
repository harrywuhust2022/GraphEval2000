import networkx as nx
import random
import json
from collections import defaultdict, deque

def generate_connected_planar_graph(n):
    while True:
        G = nx.random_tree(n)
        additional_edges = int(0.1 * n)
        while additional_edges > 0:
            u, v = random.sample(range(n), 2)
            if not G.has_edge(u, v):
                G.add_edge(u, v)
                if nx.check_planarity(G)[0]:
                    additional_edges -= 1
                else:
                    G.remove_edge(u, v)
        if nx.check_planarity(G)[0]:
            return G

def generate_disconnected_planar_graph(n):
    while True:
        G = nx.Graph()
        G.add_nodes_from(range(n))
        parts = 2
        sizes = [n // parts + (1 if x < n % parts else 0) for x in range(parts)]
        start = 0
        for size in sizes:
            H = nx.random_tree(size)
            mapping = {i: i + start for i in range(size)}
            H = nx.relabel_nodes(H, mapping)
            G = nx.compose(G, H)
            start += size
        if nx.check_planarity(G)[0]:
            return G

def generate_cyclic_planar_graph(n):
    while True:
        G = nx.cycle_graph(n)
        additional_edges = int(0.1 * n)
        while additional_edges > 0:
            u, v = random.sample(range(n), 2)
            if not G.has_edge(u, v):
                G.add_edge(u, v)
                if nx.check_planarity(G)[0]:
                    additional_edges -= 1
                else:
                    G.remove_edge(u, v)
        if nx.check_planarity(G)[0]:
            return G

def generate_acyclic_planar_graph(n):
    while True:
        G = nx.random_tree(n)
        if nx.check_planarity(G)[0]:
            return G

def Gen_label(n, edges):
    G = [[] for _ in range(n)]
    for i, j in edges:
        G[i].append(j)
        G[j].append(i)
    seen = [0] * n

    res = 0
    for i in range(n):
        if seen[i]: continue
        bfs = [i]
        seen[i] = 1
        for j in bfs:
            for k in G[j]:
                if seen[k] == 0:
                    bfs.append(k)
                    seen[k] = 1
        if all(len(G[j]) == len(bfs) - 1 for j in bfs):
            res += 1
    return res

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [generate_connected_planar_graph, generate_disconnected_planar_graph, generate_cyclic_planar_graph, generate_acyclic_planar_graph]
    graph_labels = ["connected", "disconnected", "cyclic", "acyclic"]
    data = {label: {"graphs": [], "n": [], "labels": [], "complexity": []} for label in graph_labels}

    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            G = graph_func(n)
            edges = list(G.edges())
            label_check = Gen_label(n, edges)
            data[label]["n"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(edges))

    with open(filename, 'w') as file:
        for label in graph_labels:
            entry = json.dumps({label: data[label]})
            file.write(entry + '\n')

if __name__ == '__main__':
    generate_and_save_graphs(10, 20, 200, '../../../dataset/undirected/lc2685/planar.jsonl')
