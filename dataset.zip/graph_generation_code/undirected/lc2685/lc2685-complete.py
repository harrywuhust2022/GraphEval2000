import networkx as nx
import random
import json
from collections import *

def connected_complete_graph(n):
    G = nx.complete_graph(n)
    return G.edges()

""" correct solutions """
def Gen_label(n, edges):
        G = [[] for i in range(n)]
        for i,j in edges:
            G[i].append(j)
            G[j].append(i)
        seen = [0] * n

        res = 0
        for i in range(n):
            if seen[i]: continue
            bfs = [i]
            seen[i] = 1
            for j in bfs:
                for k in G[j]:
                    if seen[k] == 0:
                        bfs.append(k)
                        seen[k] = 1
            if all(len(G[j]) == len(bfs) - 1 for j in bfs):
                res += 1
        return res

""" This func is specific to complete graph!!! """
def calculate_complexity(n):
    return n * (n - 1) // 2

def generate_and_save_graph_data(num_graphs, min_n, max_n, filename):
    data = {"connected": {"graphs": [], "n": [], "labels": [], "complexity": []}}
    for _ in range(num_graphs):
        n = random.randint(min_n, max_n)
        edges = list(connected_complete_graph(n))
        complexity = calculate_complexity(n)
        label = Gen_label(n, edges)

        data["connected"]["n"].append(n)
        data["connected"]["graphs"].append(edges)
        data["connected"]["labels"].append(label)
        data["connected"]["complexity"].append(complexity)
    
    with open(filename, 'w') as file:
        file.write(json.dumps(data) + '\n')

if __name__ == '__main__':
    generate_and_save_graph_data(10, 20, 200, './dataset/undirected/lc2685/complete.jsonl')
