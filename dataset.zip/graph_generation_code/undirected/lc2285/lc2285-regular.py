from collections import defaultdict
from itertools import accumulate, chain, product
from typing import Counter, List
import networkx as nx
import random
import json

def connected_regular_graph(n):
    """Generate a connected regular graph with n nodes and random degree."""
    degree = random.randint(2, max(2, min(n-1, 10)))  # Ensure degree is possible
    if n * degree % 2 != 0:  # For regular graphs n * degree must be even
        degree += 1
    G = nx.random_regular_graph(degree, n)
    return G

def disconnected_regular_graph(n):
    """Generate a disconnected regular graph."""
    G = nx.Graph()
    while G.number_of_nodes() < n:
        remaining_nodes = n - G.number_of_nodes()
        if remaining_nodes == 1:
            # Can't create a regular graph with 1 node if degree > 0
            G.add_node(G.number_of_nodes())
            break
        
        # Ensuring component size is between 2 and remaining_nodes, but also even if necessary
        component_size = random.randint(2, min(20, remaining_nodes))
        degree = random.randint(1, max(1, min(component_size - 1, 10)))

        if component_size * degree % 2 != 0:  # Adjust degree if needed to ensure even product
            degree = degree - 1 if degree > 1 else degree + 1

        if degree >= component_size or degree * component_size % 2 != 0:
            continue  # Skip if the degree is not feasible or can't form a regular graph

        try:
            component = nx.random_regular_graph(degree, component_size)
        except nx.NetworkXError:
            continue  # Handle cases where NetworkX can't form a regular graph with given parameters

        component = nx.relabel_nodes(component, {i: i + G.number_of_nodes() for i in range(component_size)})
        G = nx.compose(G, component)

    return G


def cyclic_regular_graph(n):
    """Generate a cyclic regular graph."""
    degree = 2  # For a cyclic graph to be regular, each node must have 2 and only 2 neighbors
    G = nx.cycle_graph(n)
    return G

def gen_label(n: int, roads: List[List[int]]) -> int:
        
        '''The main idea is to count the frequency of the cities connected to roads and then 
           keep on assigning the integer value from one to n to each cities after sorting it. '''
        
        f = [0 for _ in range(n)]   # for storing the frequency of each city connected to pathways
        
        for x, y in roads:
            f[x] += 1
            f[y] += 1
        
        f.sort()
        s = 0
        for i in range(len(f)):
            s += f[i] * (i+1)  # assigning and storing the integer value to each cities frequency in ascending order
        return s

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [connected_regular_graph, disconnected_regular_graph, cyclic_regular_graph]
    graph_labels = ["connected", "disconnected", "cyclic"]
    
    # Initialize the dictionary to store graph data
    data = {label: {"graphs": [], "numNodes": [], "labels": [], "complexity": []} for label in graph_labels}
    
    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)  # Randomly choose the number of nodes within the given range
            G = graph_func(n)  # Generate the graph
            edges = list(G.edges())  # List of edges in the graph
            label_check = gen_label(n, edges)  # Assuming Gen_label is a function to generate labels
            
            # Store graph information in the data dictionary
            data[label]["numNodes"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(edges))  # Number of edges as a measure of complexity
    
    # Write the data to a jsonl file
    with open(filename, 'w') as file:
        for label in graph_labels:
            entry = json.dumps({label: data[label]})
            file.write(entry + '\n')

# Example usage
generate_and_save_graphs(10, 5, 50, '../../../dataset/undirected/lc2285/regular.jsonl')