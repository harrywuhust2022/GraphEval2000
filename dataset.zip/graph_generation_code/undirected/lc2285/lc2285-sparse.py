from collections import defaultdict
from itertools import accumulate, chain, product
from typing import Counter, List
import networkx as nx
import random
import json

def connected_sparse_graph(n):
    G = nx.random_tree(n)
    # Adding more edges to ensure the graph remains sparse but connected
    additional_edges = min(n, max(5, n // 10))
    while additional_edges > 0:
        u, v = random.sample(range(n), 2)
        if not G.has_edge(u, v):
            G.add_edge(u, v)
            additional_edges -= 1
    return G

def disconnected_sparse_graph(n):
    G = nx.Graph()
    # Start by ensuring the graph has nodes labeled from 0 to n-1
    G.add_nodes_from(range(n))
    
    # Create multiple components, each of a random size between 2 and min(20, remaining_nodes)
    start = 0
    while start < n:
        if n - start == 1:  # Handle case where only one node is left
            break

        # Calculate the size of the next component
        component_size = random.randint(2, min(20, n - start))
        if n - start - component_size < 2:
            component_size = n - start  # If fewer than 2 nodes would remain, adjust the size

        # Generate a connected subgraph for this component
        H = nx.random_tree(component_size)
        mapping = {i: i + start for i in range(component_size)}
        H = nx.relabel_nodes(H, mapping)
        G = nx.compose(G, H)
        
        start += component_size

    return G


def cyclic_sparse_graph(n):
    G = nx.cycle_graph(n)
    additional_edges = min(n, max(3, n // 15))
    while additional_edges > 0:
        u, v = random.sample(range(n), 2)
        if not G.has_edge(u, v):
            G.add_edge(u, v)
            additional_edges -= 1
    return G

def acyclic_sparse_graph(n):
    G = nx.random_tree(n)
    return G

def gen_label(n: int, roads: List[List[int]]) -> int:
        
        '''The main idea is to count the frequency of the cities connected to roads and then 
           keep on assigning the integer value from one to n to each cities after sorting it. '''
        
        f = [0 for _ in range(n)]   # for storing the frequency of each city connected to pathways
        
        for x, y in roads:
            f[x] += 1
            f[y] += 1
        
        f.sort()
        s = 0
        for i in range(len(f)):
            s += f[i] * (i+1)  # assigning and storing the integer value to each cities frequency in ascending order
        return s

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [connected_sparse_graph, disconnected_sparse_graph, cyclic_sparse_graph, acyclic_sparse_graph]
    graph_labels = ["connected", "disconnected", "cyclic", "acyclic"]
    
    # Initialize the dictionary to store graph data
    data = {label: {"graphs": [], "numNodes": [], "labels": [], "complexity": []} for label in graph_labels}
    
    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)  # Randomly choose the number of nodes within the given range
            G = graph_func(n)  # Generate the graph
            edges = list(G.edges())  # List of edges in the graph
            label_check = gen_label(n, edges)  # Assuming Gen_label is a function to generate labels
            
            # Store graph information in the data dictionary
            data[label]["numNodes"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(edges))  # Number of edges as a measure of complexity
    
    # Write the data to a jsonl file
    with open(filename, 'w') as file:
        for label in graph_labels:
            entry = json.dumps({label: data[label]})
            file.write(entry + '\n')

# Example usage
generate_and_save_graphs(10, 5, 50, '../../../dataset/undirected/lc2285/sparse.jsonl')
