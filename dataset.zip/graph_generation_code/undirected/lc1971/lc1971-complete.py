import networkx as nx
import random
import json
from collections import *

def connected_complete_graph(n):
    G = nx.complete_graph(n)
    return G.edges()

""" correct solutions """
def Gen_label(n, edges, source, destination):
    graph = defaultdict(list)
    for u, v in edges:
        graph[u].append(v)
        graph[v].append(u)
    
    queue = deque([source])
    visited = set([source])
    
    while queue:
        node = queue.popleft()
        if node == destination:
            return True
        for neighbor in graph[node]:
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)
    
    return False

""" This func is specific to complete graph!!! """
def calculate_complexity(n):
    return n * (n - 1) // 2

def generate_and_save_graph_data(num_graphs, min_n, max_n, filename):
    data = {"graphs": [], "n_list": [], "labels": [], "complexity": []}
    for _ in range(num_graphs):
        n = random.randint(min_n, max_n)
        edges = list(connected_complete_graph(n))
        complexity = calculate_complexity(n)
        label = Gen_label(n, edges, 0, n-1)

        data["n_list"].append(n)
        data["graphs"].append(edges)
        data["labels"].append(label)
        data["complexity"].append(complexity)
    
    with open(filename, 'w') as file:
        file.write(json.dumps(data) + '\n')

if __name__ == '__main__':
    generate_and_save_graph_data(10, 20, 200, './dataset/undirected/lc1971/complete.jsonl')
