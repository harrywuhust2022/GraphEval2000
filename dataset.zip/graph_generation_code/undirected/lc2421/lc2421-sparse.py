from collections import defaultdict, deque
from typing import Counter, List
import networkx as nx
import json
import random

def generate_tree_graph(n):
    # Generate a tree with n nodes
    return nx.random_tree(n, seed=random.randint(1, 1000))

def gen_label(n: int, edges: List[List[int]], restricted: List[int]) -> int:
        adj_list = defaultdict(list)
        for x,y in edges:
            adj_list[x].append(y)
            adj_list[y].append(x)
    
        que = deque()
        que.append(0)
        result = 0
        visited = set()
        for node in restricted:
            visited.add(node)

        while que:
            cur = que.popleft()
            if cur in visited:
                continue    
            visited.add(cur)
            result += 1
            for node in adj_list[cur]:
                que.append(node)
        
        return result

def gen_label(vals: List[int], edges: List[List[int]]) -> int:
        n = len(vals)
        p = list(range(n))
        count = [Counter({vals[i]:1}) for i in range(n)]
        edges = sorted((max(vals[i],vals[j]),i,j) for i,j in edges)
        res = n
        def find(i):
            if p[i] != i:p[i] = find(p[i])
            return p[i]
        for val, i, j in edges:
            pi, pj = find(i), find(j)
            res += count[pi][val]*count[pj][val]
            p[pi] = pj
            count[pj][val] += count[pi][val]
        return res

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [generate_tree_graph, generate_tree_graph]
    graph_labels = ["connected", "acyclic"]
    data = {label: {"graphs": [], "numNodes": [], "values": [], "labels": [], "complexity": []} for label in graph_labels}
    
    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            G = graph_func(n)
            edges = list(G.edges())
            values = [random.randint(0, 100000) for _ in range(n)]

            label_check = gen_label(values, edges)
        

            data[label]["numNodes"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["values"].append(values)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(edges))  # Number of edges as a measure of complexity

    # Writing the data to a JSONL file
    with open(filename, 'w') as file:
        for item in data.items():
            file.write(json.dumps({item[0]: item[1]}))
            file.write('\n')

# Function call to generate the graph datasets and save them
generate_and_save_graphs(10, 20, 200, '../../../dataset/undirected/lc2421/sparse.jsonl')