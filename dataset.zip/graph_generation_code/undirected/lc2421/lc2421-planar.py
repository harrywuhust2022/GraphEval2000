import networkx as nx
import json
import random
from collections import defaultdict, deque, Counter
from typing import List

def generate_connected_planar_graph(n):
    while True:
        G = nx.random_tree(n)
        additional_edges = int(0.1 * n)
        while additional_edges > 0:
            u, v = random.sample(range(n), 2)
            if not G.has_edge(u, v):
                G.add_edge(u, v)
                if nx.check_planarity(G)[0]:
                    additional_edges -= 1
                else:
                    G.remove_edge(u, v)
        if nx.check_planarity(G)[0]:
            return G

def generate_disconnected_planar_graph(n):
    while True:
        G = nx.Graph()
        G.add_nodes_from(range(n))
        parts = 2
        sizes = [n // parts + (1 if x < n % parts else 0) for x in range(parts)]
        start = 0
        for size in sizes:
            H = nx.random_tree(size)
            mapping = {i: i + start for i in range(size)}
            H = nx.relabel_nodes(H, mapping)
            G = nx.compose(G, H)
            start += size
        if nx.check_planarity(G)[0]:
            return G

def generate_cyclic_planar_graph(n):
    while True:
        G = nx.cycle_graph(n)
        additional_edges = int(0.1 * n)
        while additional_edges > 0:
            u, v = random.sample(range(n), 2)
            if not G.has_edge(u, v):
                G.add_edge(u, v)
                if nx.check_planarity(G)[0]:
                    additional_edges -= 1
                else:
                    G.remove_edge(u, v)
        if nx.check_planarity(G)[0]:
            return G

def generate_acyclic_planar_graph(n):
    while True:
        G = nx.random_tree(n)
        if nx.check_planarity(G)[0]:
            return G

def gen_label(vals: List[int], edges: List[List[int]]) -> int:
    n = len(vals)
    p = list(range(n))
    count = [Counter({vals[i]:1}) for i in range(n)]
    edges = sorted((max(vals[i],vals[j]),i,j) for i,j in edges)
    res = n
    def find(i):
        if p[i] != i:
            p[i] = find(p[i])
        return p[i]
    for val, i, j in edges:
        pi, pj = find(i), find(j)
        res += count[pi][val] * count[pj][val]
        p[pi] = pj
        count[pj][val] += count[pi][val]
    return res

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [generate_connected_planar_graph, generate_disconnected_planar_graph, generate_cyclic_planar_graph, generate_acyclic_planar_graph]
    graph_labels = ["connected", "disconnected", "cyclic", "acyclic"]
    data = {label: {"graphs": [], "numNodes": [], "values": [], "labels": [], "complexity": []} for label in graph_labels}

    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            G = graph_func(n)
            edges = list(G.edges())
            values = [random.randint(0, 100000) for _ in range(n)]
            label_check = gen_label(values, edges)

            data[label]["numNodes"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["values"].append(values)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(edges))  # Number of edges as a measure of complexity

    with open(filename, 'w') as file:
        for item in data.items():
            file.write(json.dumps({item[0]: item[1]}))
            file.write('\n')

# Function call to generate the graph datasets and save them
generate_and_save_graphs(10, 20, 200, '../../../dataset/undirected/lc2421/planar.jsonl')
