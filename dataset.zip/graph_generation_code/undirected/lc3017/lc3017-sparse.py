import networkx as nx
import json
import random
from itertools import accumulate
import operator

def generate_connected_sparse_graph(n, x, y):
    G = nx.path_graph(n)
    G.add_edge(x - 1, y - 1)
    return G

def generate_disconnected_sparse_graph(n, x, y):
    G = nx.Graph()
    component1_size = n // 2
    component2_size = n - component1_size
    G.add_nodes_from(range(n))
    G.add_edges_from((i, i + 1) for i in range(component1_size - 1))
    G.add_edges_from((i, i + 1) for i in range(component1_size, n - 1))
    return G

def generate_cyclic_sparse_graph(n, x, y):
    G = nx.cycle_graph(n)
    if x != y:
        G.add_edge(x - 1, y - 1)
    return G

def generate_acyclic_sparse_graph(n, x, y):
    G = nx.random_tree(n)
    return G

def Gen_label(n, x, y):
    x, y = min(x, y), max(x, y)
    A = [0] * n
    for i in range(1, n + 1):
        A[0] += 2 									# go left and right
        A[min(i - 1, abs(i - y) + x)] -= 1 			# reach 1 then stop
        A[min(n - i, abs(i - x) + 1 + n - y)] -= 1 	# reach n then stop
        A[min(abs(i - x), abs(y - i) + 1)] += 1 	# reach x then split
        A[min(abs(i - x) + 1, abs(y - i))] += 1 	# reach y then split
        r = max(x - i, 0) + max(i - y, 0)
        A[r + (y - x + 0) // 2] -= 1 				# i -> x -> y <- x
        A[r + (y - x + 1) // 2] -= 1 				# i -> y -> x <- y
    return list(accumulate(A))

def create_graph_samples(category_func, count=10):
    graph_data = {'n': [], 'x': [], 'y': [], 'labels': [], 'complexity': []}
    for _ in range(count):
        n = random.randint(20, 200)
        x, y = random.randint(1, n), random.randint(1, n)
        G = category_func(n, x, y)
        graph_data['n'].append(n)
        graph_data['x'].append(x)
        graph_data['y'].append(y)
        graph_data['labels'].append(Gen_label(n, x, y))  # Assuming Gen_label is defined elsewhere
        graph_data['complexity'].append(len(G.edges()))
    return graph_data

def main():
    categories = {
        "connected": generate_connected_sparse_graph,
        "disconnected": generate_disconnected_sparse_graph,
        "cyclic": generate_cyclic_sparse_graph,
        "acyclic": generate_acyclic_sparse_graph
    }
    results = {}
    for label, func in categories.items():
        results[label] = create_graph_samples(func)

    with open('./dataset/undirected/lc3017/sparse.jsonl', 'w') as file:
        json.dump(results, file)

if __name__ == "__main__":
    main()
