import networkx as nx
import random
import matplotlib.pyplot as plt
from collections import *
import json

""" create graphs """

def create_self_loops_and_multiple_edges(G, nodes, probability=0.2, multiPro=0.05):
    if not nodes:
        return
    
    guaranteed_self_loop_node = random.choice(list(nodes))
    G.add_edge(guaranteed_self_loop_node, guaranteed_self_loop_node)

    for node in nodes:
        if node != guaranteed_self_loop_node and random.random() < probability:
            G.add_edge(node, node)

def connected_pseudo_graph(n, d):
    G = nx.random_regular_graph(d, n)
    create_self_loops_and_multiple_edges(G, G.nodes())
    return G

def disconnected_pseudo_graph(n, d):
    num_components = 2
    G = nx.Graph()
    sizes = [n // num_components + (1 if i < n % num_components else 0) for i in range(num_components)]
    start = 0
    for size in sizes:
        subgraph = nx.random_regular_graph(d, size)
        mapping = {i: i + start for i in range(size)}
        subgraph = nx.relabel_nodes(subgraph, mapping)
        G = nx.compose(G, subgraph)
        start += size
    create_self_loops_and_multiple_edges(G, G.nodes())
    return G

def cyclic_pseudo_graph(n, d):
    G = nx.random_regular_graph(d, n)
    nodes = list(G.nodes())
    for i in range(len(nodes)):
        G.add_edge(nodes[i], nodes[(i+1) % len(nodes)])
    create_self_loops_and_multiple_edges(G, G.nodes())
    return G

""" create labels """
def Gen_label(n, edges):
    G = [set() for i in range(n)]
    for i,j in edges:
        G[i-1].add(j-1)
        G[j-1].add(i-1)
    odd = [i for i in range(n) if len(G[i]) % 2]

    def f(a,b):
        return a not in G[b]

    if len(odd) == 2:
        a, b = odd
        return any(f(a,i) and f(b,i) for i in range(n))

    if len(odd) == 4:
        a,b,c,d = odd
        return  f(a,b) and f(c,d) or \
                f(a,c) and f(b,d) or \
                f(a,d) and f(c,b)
    return len(odd) == 0

""" create jsonl files """

def generate_and_save_graphs(num_graphs, min_n, max_n, d, filename):
    graph_types = [connected_pseudo_graph, disconnected_pseudo_graph, cyclic_pseudo_graph]
    graph_labels = ["connected", "disconnected", "cyclic"]
    data = {label: {"graphs": [], "n": [], "labels": [], "complexity": []} for label in graph_labels}
    
    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            G = graph_func(n, d)
            edges = list(G.edges())
            complexity = len(edges)  # Assuming complexity measure by number of edges
            label_check = Gen_label(n, edges)
            
            data[label]["n"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(complexity)
    
    with open(filename, 'w') as file:
        file.write(json.dumps(data))

if __name__ == '__main__':
    generate_and_save_graphs(10, 20, 200, d=4, filename='./dataset/undirected/lc2508/pseudo.jsonl')