import networkx as nx
import random
import json
from collections import defaultdict, deque

def connected_regular_graph(n, d):
    """Generate a connected regular graph with n nodes and degree d."""
    if d * n % 2 != 0:
        raise ValueError("d * n must be even for a regular graph.")
    return nx.random_regular_graph(d, n)

def disconnected_regular_graph(n, d):
    """Generate a disconnected regular graph with n nodes and degree d."""
    num_components = 2
    if d * n % 2 != 0 or n % num_components != 0:
        raise ValueError("d * n must be even and n must be divisible by the number of components.")
    component_size = n // num_components
    G = nx.Graph()
    for start in range(0, n, component_size):
        H = nx.random_regular_graph(d, component_size)
        mapping = {i: i + start for i in range(component_size)}
        H = nx.relabel_nodes(H, mapping)
        G = nx.compose(G, H)
    return G

def cyclic_regular_graph(n, d):
    """Generate a cyclic regular graph with n nodes and degree d."""
    if n < d:
        raise ValueError("n must be at least as large as d for a valid cyclic graph.")
    G = connected_regular_graph(n, d)
    # Adding a single cycle
    nodes = list(G.nodes())
    for i in range(n):
        G.add_edge(nodes[i], nodes[(i+1) % n])
    return G


def Gen_label(n, edges):
    G = [set() for i in range(n)]
    for i,j in edges:
        G[i-1].add(j-1)
        G[j-1].add(i-1)
    odd = [i for i in range(n) if len(G[i]) % 2]

    def f(a,b):
        return a not in G[b]

    if len(odd) == 2:
        a, b = odd
        return any(f(a,i) and f(b,i) for i in range(n))

    if len(odd) == 4:
        a,b,c,d = odd
        return  f(a,b) and f(c,d) or \
                f(a,c) and f(b,d) or \
                f(a,d) and f(c,b)
    return len(odd) == 0


def generate_and_save_graphs(num_graphs, min_n, max_n, d, filename):
    graph_types = [connected_regular_graph, disconnected_regular_graph, cyclic_regular_graph]
    graph_labels = ["connected", "disconnected", "cyclic"]
    data = {label: {"graphs": [], "n": [], "labels": [], "complexity": []} for label in graph_labels}
    
    # Adjust range to ensure n is always even, and ensuring min_n is not zero
    min_n = max((min_n + 1) // 2 if min_n % 2 != 0 else min_n // 2, 1)
    max_n = max_n // 2

    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n) * 2
            G = graph_func(n, d)
            edges = list(G.edges())
            complexity = len(edges)  # Assuming complexity measure by number of edges
            label_check = Gen_label(n, edges)
            
            data[label]["n"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(complexity)
    
    with open(filename, 'w') as file:
        for item in data.items():
            file.write(json.dumps({item[0]: item[1]}))
            file.write('\n')

if __name__ == '__main__':
    generate_and_save_graphs(10, 20, 200, d=4, filename='./dataset/undirected/lc2508/regular.jsonl')