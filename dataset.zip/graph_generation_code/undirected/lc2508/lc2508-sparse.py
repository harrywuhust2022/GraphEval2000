import networkx as nx
import random
import json
from collections import defaultdict, deque

def connected_sparse_graph(n):
    G = nx.Graph()
    G.add_nodes_from(range(n))
    for i in range(1, n):
        G.add_edge(i - 1, i)
    extra_edges = int(0.1 * n)
    while extra_edges > 0:
        u, v = random.sample(range(n), 2)
        if not G.has_edge(u, v):
            G.add_edge(u, v)
            extra_edges -= 1
    return G

def disconnected_sparse_graph(n):
    G = nx.Graph()
    G.add_nodes_from(range(n))
    parts = 2
    sizes = [n // parts + (1 if x < n % parts else 0) for x in range(parts)]
    start = 0
    for size in sizes:
        for i in range(start + 1, start + size):
            if random.random() < 0.1:
                G.add_edge(i - 1, i)
        start += size
    return G

def cyclic_sparse_graph(n):
    G = nx.Graph()
    G.add_nodes_from(range(n))
    for i in range(n):
        G.add_edge(i, (i + 1) % n)
    return G

def acyclic_sparse_graph(n):
    G = nx.Graph()
    G.add_nodes_from(range(n))
    for i in range(1, n):
        G.add_edge(i, random.randint(0, i - 1))
    return G


def Gen_label(n, edges):
    G = [set() for i in range(n)]
    for i,j in edges:
        G[i-1].add(j-1)
        G[j-1].add(i-1)
    odd = [i for i in range(n) if len(G[i]) % 2]

    def f(a,b):
        return a not in G[b]

    if len(odd) == 2:
        a, b = odd
        return any(f(a,i) and f(b,i) for i in range(n))

    if len(odd) == 4:
        a,b,c,d = odd
        return  f(a,b) and f(c,d) or \
                f(a,c) and f(b,d) or \
                f(a,d) and f(c,b)
    return len(odd) == 0


def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [connected_sparse_graph, disconnected_sparse_graph, cyclic_sparse_graph, acyclic_sparse_graph]
    graph_labels = ["connected", "disconnected", "cyclic", "acyclic"]
    data = {label: {"graphs": [], "n": [], "labels": [], "complexity": []} for label in graph_labels}
    
    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            G = graph_func(n)
            edges = list(G.edges())
            label_check = Gen_label(n, edges)
            data[label]["n"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(edges))  # Number of edges as a measure of complexity

    with open(filename, 'w') as file:
        for item in data.items():
            file.write(json.dumps({item[0]: item[1]}))
            file.write('\n')

if __name__ == '__main__':
    generate_and_save_graphs(10, 20, 200, './dataset/undirected/lc2508/sparse.jsonl')