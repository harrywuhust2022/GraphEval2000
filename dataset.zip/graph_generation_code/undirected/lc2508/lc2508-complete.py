import networkx as nx
import random
import json
from collections import *

def connected_complete_graph(n):
    G = nx.complete_graph(n)
    return G.edges()

""" correct solutions """
def Gen_label(n, edges):
    G = [set() for i in range(n)]
    for i,j in edges:
        G[i-1].add(j-1)
        G[j-1].add(i-1)
    odd = [i for i in range(n) if len(G[i]) % 2]

    def f(a,b):
        return a not in G[b]

    if len(odd) == 2:
        a, b = odd
        return any(f(a,i) and f(b,i) for i in range(n))

    if len(odd) == 4:
        a,b,c,d = odd
        return  f(a,b) and f(c,d) or \
                f(a,c) and f(b,d) or \
                f(a,d) and f(c,b)
    return len(odd) == 0

""" This func is specific to complete graph!!! """
def calculate_complexity(n):
    return n * (n - 1) // 2

def generate_and_save_graph_data(num_graphs, min_n, max_n, filename):
    data = {"connected":{"graphs": [], "n": [], "labels": [], "complexity": []}}
    for _ in range(num_graphs):
        n = random.randint(min_n, max_n)
        edges = list(connected_complete_graph(n))
        complexity = calculate_complexity(n)
        label = Gen_label(n, edges)

        data["connected"]["n"].append(n)
        data["connected"]["graphs"].append(edges)
        data["connected"]["labels"].append(label)
        data["connected"]["complexity"].append(complexity)
    
    with open(filename, 'w') as file:
        for item in data.items():
            file.write(json.dumps({item[0]: item[1]}))
            file.write('\n')

if __name__ == '__main__':
    generate_and_save_graph_data(10, 20, 200, './dataset/undirected/lc2508/complete.jsonl')
