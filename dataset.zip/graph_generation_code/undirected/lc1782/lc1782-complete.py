from collections import defaultdict
from typing import List
import networkx as nx
import random
import json

def connected_complete_graph(n):
    """Generate a complete graph with n nodes."""
    G = nx.complete_graph(n)
    return G

def generate_queries(n):
    # Scale query generation with the number of nodes
    return [random.randint(1, n) for _ in range(random.randint(1, 20))]

def gen_label(n: int, edges: List[List[int]], queries: List[int]) -> List[int]:
        h = defaultdict(list)
        freq = defaultdict(int)
        for i in range(n):
            freq[i+1] = 0
        for i,j in edges:
            freq[i] += 1
            freq[j] += 1
            freq[(min(i, j), max(i,j))] += 1
        ans = []
        temp = [i for key,i in freq.items() if type(key) is int]
        rem = [key for key in freq if type(key) is not int]
        temp.sort()
        for val in queries:
            cnt = 0
            hi = len(temp)-1
            low = 0
            while low < hi:
                if temp[low] + temp[hi] > val:
                    cnt += hi-low
                    hi -= 1
                else:
                    low += 1
            ans.append(cnt)
        for i,j in rem:
            val = freq[i] + freq[j] - freq[(i,j)]
            for x in range(len(queries)):
                if val <= queries[x] and freq[i] + freq[j] > queries[x]:
                    # print(val, i, j, queries[x], freq[(i,j)])
                    ans[x] -= 1
        return ans

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [connected_complete_graph]
    graph_labels = ["connected"]
    data = {label: {"graphs": [], "numNodes": [], "queries": [], "labels": [], "complexity": []} for label in graph_labels}

    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            G = graph_func(n)
            edges = list(G.edges())
            queries = generate_queries(n)
            label_check = gen_label(n, edges, queries)
            data[label]["numNodes"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["queries"].append(queries)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(edges))  # Number of edges as a measure of complexity

    with open(filename, 'w') as file:
        for label, contents in data.items():
            entry = {label: contents}
            file.write(json.dumps(entry) + '\n')

# Example usage
generate_and_save_graphs(10, 20, 200, '../../../dataset/undirected/lc1782/complete.jsonl')
