from collections import defaultdict
from itertools import accumulate, chain, product
from typing import Counter, List
import networkx as nx
import random
import json

def connected_sparse_graph(n):
    G = nx.random_tree(n)
    # Adding more edges to ensure the graph remains sparse but connected
    additional_edges = min(n, max(5, n // 10))
    while additional_edges > 0:
        u, v = random.sample(range(n), 2)
        if not G.has_edge(u, v):
            G.add_edge(u, v)
            additional_edges -= 1
    return G

def disconnected_sparse_graph(n):
    G = nx.Graph()
    # Start by ensuring the graph has nodes labeled from 0 to n-1
    G.add_nodes_from(range(n))
    
    # Create multiple components, each of a random size between 2 and min(20, remaining_nodes)
    start = 0
    while start < n:
        if n - start == 1:  # Handle case where only one node is left
            break

        # Calculate the size of the next component
        component_size = random.randint(2, min(20, n - start))
        if n - start - component_size < 2:
            component_size = n - start  # If fewer than 2 nodes would remain, adjust the size

        # Generate a connected subgraph for this component
        H = nx.random_tree(component_size)
        mapping = {i: i + start for i in range(component_size)}
        H = nx.relabel_nodes(H, mapping)
        G = nx.compose(G, H)
        
        start += component_size

    return G


def cyclic_sparse_graph(n):
    G = nx.cycle_graph(n)
    additional_edges = min(n, max(3, n // 15))
    while additional_edges > 0:
        u, v = random.sample(range(n), 2)
        if not G.has_edge(u, v):
            G.add_edge(u, v)
            additional_edges -= 1
    return G

def acyclic_sparse_graph(n):
    G = nx.random_tree(n)
    return G

def generate_queries(n):
    # Scale query generation with the number of nodes
    return [random.randint(1, n) for _ in range(random.randint(1, 20))]

def gen_label(n: int, edges: List[List[int]], queries: List[int]) -> List[int]:
        h = defaultdict(list)
        freq = defaultdict(int)
        for i in range(n):
            freq[i+1] = 0
        for i,j in edges:
            freq[i] += 1
            freq[j] += 1
            freq[(min(i, j), max(i,j))] += 1
        ans = []
        temp = [i for key,i in freq.items() if type(key) is int]
        rem = [key for key in freq if type(key) is not int]
        temp.sort()
        for val in queries:
            cnt = 0
            hi = len(temp)-1
            low = 0
            while low < hi:
                if temp[low] + temp[hi] > val:
                    cnt += hi-low
                    hi -= 1
                else:
                    low += 1
            ans.append(cnt)
        for i,j in rem:
            val = freq[i] + freq[j] - freq[(i,j)]
            for x in range(len(queries)):
                if val <= queries[x] and freq[i] + freq[j] > queries[x]:
                    # print(val, i, j, queries[x], freq[(i,j)])
                    ans[x] -= 1
        return ans

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [connected_sparse_graph, disconnected_sparse_graph, cyclic_sparse_graph, acyclic_sparse_graph]
    graph_labels = ["connected", "disconnected", "cyclic", "acyclic"]
    data = {label: {"graphs": [], "numNodes": [], "queries": [], "labels": [], "complexity": []} for label in graph_labels}

    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            G = graph_func(n)
            edges = list(G.edges())
            queries = generate_queries(n)
            label_check = gen_label(n, edges, queries)
            data[label]["numNodes"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["queries"].append(queries)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(edges))  # Number of edges as a measure of complexity

    with open(filename, 'w') as file:
        for label, contents in data.items():
            entry = {label: contents}
            file.write(json.dumps(entry) + '\n')

# Example usage
generate_and_save_graphs(10, 20, 200, '../../../dataset/undirected/lc1782/sparse.jsonl')
