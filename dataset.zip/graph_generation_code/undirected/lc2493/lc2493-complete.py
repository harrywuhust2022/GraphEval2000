import networkx as nx
import random
import json
from collections import *

def connected_complete_graph(n):
    G = nx.complete_graph(n)
    return G


def bfs(graph, i):
    queue = deque([i])
    seen = set([i])
    seenLevel = set()
    ans = 0
    while queue:
        ans += 1
        nextLevel = set()
        for _ in range(len(queue)):
            node = queue.popleft()
            for neighbor in graph[node]:
                if neighbor in seenLevel:
                    return -1
                if neighbor in seen:
                    continue
                seen.add(neighbor)
                nextLevel.add(neighbor)
                queue.append(neighbor)
        seenLevel = nextLevel
    return ans

def Gen_label(n, edges):
    graph = defaultdict(list)
    for a, b in edges:
        graph[a].append(b)
        graph[b].append(a)
    components = []
    seen = set()
    for i in range(1, n + 1):
        if i in seen:
            continue
        queue = deque([i])
        visited = set([i])
        while queue:
            for _ in range(len(queue)):
                node = queue.popleft()
                for neighbor in graph[node]:
                    if neighbor in visited:
                        continue
                    visited.add(neighbor)
                    queue.append(neighbor)
        components.append(visited)
        seen = seen.union(visited)
    longest = [-1] * len(components)        
    for k in range(len(components)):
        for i in components[k]:
            longest[k] = max(longest[k], bfs(graph, i))
    if min(longest) < 0:
        return -1
    return sum(longest)


""" This func is specific to complete graph!!! """
def calculate_complexity(n):
    return n * (n - 1) // 2

def generate_and_save_graph_data(num_graphs, min_n, max_n, filename):
    graph_types = [connected_complete_graph]
    graph_labels = ["connected"]
    data = {label: {"graphs": [], "n": [], "labels": [], "complexity": []} for label in graph_labels}
    
    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            G = graph_func(n)
            edges = list(G.edges())
            complexity = calculate_complexity(n)
            label_check = Gen_label(n, edges)

            data[label]["n"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(complexity)
    
    with open(filename, 'w') as file:
        for item in data.items():
            file.write(json.dumps({item[0]: item[1]}))
            file.write('\n')

if __name__ == '__main__':
    generate_and_save_graph_data(10, 20, 200, './dataset/undirected/lc2493/complete.jsonl')
