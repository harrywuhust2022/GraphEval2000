from collections import defaultdict
import heapq
import networkx as nx
import random
import json
from typing import List

class Pair:
    def __init__(self, node, score):
        self.node = node
        self.score = score
    def __lt__(self, other):
        return self.score < other.score

def connected_planar_graph(n):
    while True:
        G = nx.random_tree(n)
        additional_edges = min(n, max(5, n // 10))
        while additional_edges > 0:
            u, v = random.sample(range(n), 2)
            if not G.has_edge(u, v):
                G.add_edge(u, v)
                additional_edges -= 1
        if nx.check_planarity(G)[0]:
            return G

def disconnected_planar_graph(n):
    while True:
        G = nx.Graph()
        G.add_nodes_from(range(n))
        start = 0
        while start < n:
            if n - start == 1:
                break
            component_size = random.randint(2, min(20, n - start))
            if n - start - component_size < 2:
                component_size = n - start
            H = nx.random_tree(component_size)
            mapping = {i: i + start for i in range(component_size)}
            H = nx.relabel_nodes(H, mapping)
            G = nx.compose(G, H)
            start += component_size
        if nx.check_planarity(G)[0]:
            return G

def cyclic_planar_graph(n):
    while True:
        G = nx.cycle_graph(n)
        additional_edges = min(n, max(3, n // 15))
        while additional_edges > 0:
            u, v = random.sample(range(n), 2)
            if not G.has_edge(u, v):
                G.add_edge(u, v)
                additional_edges -= 1
        if nx.check_planarity(G)[0]:
            return G

def acyclic_planar_graph(n):
    while True:
        G = nx.random_tree(n)
        if nx.check_planarity(G)[0]:
            return G

def generate_scores(n, max_score=100):
    return [random.randint(1, max_score) for _ in range(n)]

def gen_label(scores: List[int], edges: List[List[int]]) -> int:
        edgeList = [[] for i in range(len(scores))]
        for edge in edges:
            edgeList[edge[0]].append(Pair(edge[1], -1 * scores[edge[1]]))
            edgeList[edge[1]].append(Pair(edge[0], -1 * scores[edge[0]]))
            
        for nodeEdges in edgeList:
            heapq.heapify(nodeEdges)
            
        best = -1
        for e in edges:
            n0 = []
            n1 = []
            while len(edgeList[e[0]]) > 0 and len(n0) < 3:
                x = heapq.heappop(edgeList[e[0]])
                n0.append(x)
            while len(edgeList[e[1]]) > 0 and len(n1) < 3:
                x = heapq.heappop(edgeList[e[1]])
                n1.append(x)
            
            m0 = [x for x in n0 if x.node != e[1]]
            m1 = [x for x in n1 if x.node != e[0]]
            score = scores[e[0]] + scores[e[1]]
            
            if len(m0) != 0 and len(m1) != 0:
                if m0[0].node == m1[0].node:
                    if len(m0) > 1 and len(m1) == 1:
                        score += scores[m0[1].node] + scores[m1[0].node]
                        best = max(best, score)
                    elif len(m0) == 1 and len(m1) > 1:
                        score += scores[m0[0].node] + scores[m1[1].node]
                        best = max(best, score)
                    elif len(m0) > 1 and len(m1) > 1:
                        score += scores[m0[0].node] + max(scores[m0[1].node], scores[m1[1].node])
                        best = max(best, score)
                else:
                    score += scores[m0[0].node] + scores[m1[0].node]
                    best = max(best, score)
            
            for n in n0:
                heapq.heappush(edgeList[e[0]], n)
            for n in n1:
                heapq.heappush(edgeList[e[1]], n)

        return best

def generate_and_save_graphs(num_graphs, min_n, max_n, filename):
    graph_types = [connected_planar_graph, disconnected_planar_graph, cyclic_planar_graph, acyclic_planar_graph]
    graph_labels = ["connected", "disconnected", "cyclic", "acyclic"]
    data = {label: {"graphs": [], "numNodes": [], "scores": [], "labels": [], "complexity": []} for label in graph_labels}
    
    for graph_func, label in zip(graph_types, graph_labels):
        for _ in range(num_graphs):
            n = random.randint(min_n, max_n)
            G = graph_func(n)
            scores = generate_scores(n)
            edges = list(G.edges())
            label_check = gen_label(scores, edges)
            data[label]["numNodes"].append(n)
            data[label]["graphs"].append(edges)
            data[label]["scores"].append(scores)
            data[label]["labels"].append(label_check)
            data[label]["complexity"].append(len(edges))  # Number of edges as a measure of complexity
    
    with open(filename, 'w') as file:
        for label, content in data.items():
            line = json.dumps({label: content})
            file.write(line + "\n")

# Example usage
generate_and_save_graphs(10, 4, 100, '../../../dataset/undirected/lc2242/planar.jsonl')
