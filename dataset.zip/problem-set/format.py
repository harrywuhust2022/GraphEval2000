import re
import json
from ast import *
import os

def parse_text(input_text):

    # Parsing various parts using regular expressions
    leetcode_id = re.search(r"leetcode (\d+)", input_text).group(1)
    classification = re.search(r"classification: (.+)", input_text).group(1)
    difficulty = re.search(r"difficulty level: (.+)", input_text).group(1)
    problem_statement = re.search(r"Problem Statement:\n(.+?)\n\nData Examples", input_text, re.DOTALL).group(1)
    data_examples = re.findall(r"Input: (.+?)\nOutput: (.+?)\n", input_text)
    constraints = re.search(r"Constraints:(.*?)Code", input_text, re.DOTALL).group(1)
    code_framework = re.search(r"Code Framework:\n(.+)", input_text, re.DOTALL).group(1)

    # Structuring data examples into a list of dictionaries    
    formatted_data_examples = []
    for input_str, output_str in data_examples:
        # Convert the output string into a Python list
        output = literal_eval(output_str)

        input_dict = {}

        for item in input_str.split(', '):
            key, value = item.split(' = ')
            input_dict[key] = literal_eval(value)

        formatted_data_examples.append({
            "input": input_dict,
            "output": output
        })

    return {
        "leetcode_id": int(leetcode_id),
        "classification": classification,
        "difficulty": difficulty,
        "problem_statement": problem_statement.strip(),
        "data_examples": formatted_data_examples,
        "constraints": constraints.strip(),
        "code_framework": code_framework.strip()
    }

def write_jsonl(data, output_path):
    with open(output_path, 'w') as outfile:
        outfile.write(json.dumps(data) + '\n')

if __name__ == '__main__':

    # print("\n Current working directory: \n", os.getcwd())
    # input_path = './problem-set/copy-leetcode/directed/lc1719.txt'
    # with open(input_path, 'r') as file:
    #     input_text = file.read()
    # data = parse_text(input_text)
    # output_path = './problem-set/directed/lc1719.jsonl'
    # write_jsonl(data, output_path)

    directory = './copy-leetcode/undirected'
    output_directory = './undirected/'
    for filename in os.listdir(directory):
        if filename.endswith('.txt'):
            filepath = os.path.join(directory, filename)

            print("Now we process File: \n", filename)
            print("\n")

            with open(filepath, 'r') as file:
                input_text = file.read()

            data = parse_text(input_text)

            output_filename = filename.replace('.txt', '.jsonl')
            output_filepath = os.path.join(output_directory, output_filename)
            
            write_jsonl(data, output_filepath)