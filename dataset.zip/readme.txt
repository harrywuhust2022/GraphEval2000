1. `dataset` folder contains all the graph test cases.

2. `problem-set` folder contains all the data structure problems we collected from leetcode.

3. `graph_generation_code` folder contains codes that generate graphs with NetwrokX.

4. `ourmethod` folder contains the improved output results of LLMs by using proposed SSD.

5. Environment Requirement:
* python version >= 3.9.0
* install networkx