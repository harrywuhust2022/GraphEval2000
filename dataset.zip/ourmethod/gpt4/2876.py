class Solution:
    def criticalConnections(self, n: int, connections: List[List[int]]) -> List[List[int]]:
        from collections import defaultdict
        
        def dfs(u, discovery_time):
            nonlocal time
            visited[u] = True
            disc[u] = low[u] = time
            time += 1
            
            for v in graph[u]:
                if not visited[v]:
                    parent[v] = u
                    dfs(v, discovery_time)
                    
                    # Check if the subtree rooted at v has a connection back to one of the ancestors of u
                    low[u] = min(low[u], low[v])
                    
                    # If the lowest vertex reachable from subtree under v is below u in DFS tree, then u-v is a bridge
                    if low[v] > disc[u]:
                        result.append([u, v])
                elif v != parent[u]:  # Update low value of u for parent function calls.
                    low[u] = min(low[u], disc[v])
        
        # Graph representation
        graph = defaultdict(list)
        for u, v in connections:
            graph[u].append(v)
            graph[v].append(u)
        
        # Initialize discovery times and low values
        disc = [-1] * n
        low = [-1] * n
        parent = [-1] * n
        visited = [False] * n
        result = []
        time = 0
        
        # Call the recursive helper function to find Bridges
        # We start from vertex 0 (assuming graph is connected, which it should be for a server network)
        for i in range(n):
            if not visited[i]:
                dfs(i, time)
        
        return result

# Test the implementation
sol = Solution()
n_test = 6
connections_test = [[0,1], [1,2], [2,0], [1,3], [3,4], [4,5], [3,5]]
print(sol.criticalConnections(n_test, connections_test))  # Expected output: [[1, 3], [3, 4], [4, 5]]
