from collections import deque, defaultdict

def minNumberOfSemesters(n, relations, k):
    graph = defaultdict(list)
    indegree = [0] * (n + 1)
    
    # Build the graph and indegree array
    for prev, next in relations:
        graph[prev].append(next)
        indegree[next] += 1
    
    # Initialize the queue with all courses with zero indegree
    queue = deque()
    for course in range(1, n + 1):
        if indegree[course] == 0:
            queue.append(course)
    
    semester_count = 0
    processed_courses = 0
    
    # Process the courses semester by semester
    while queue:
        # Up to k courses can be taken in one semester
        semester_size = min(len(queue), k)
        for _ in range(semester_size):
            current = queue.popleft()
            processed_courses += 1
            # Decrement indegree of next courses
            for next_course in graph[current]:
                indegree[next_course] -= 1
                if indegree[next_course] == 0:
                    queue.append(next_course)
        
        # Increment the semester count after processing up to k courses
        semester_count += 1
    
    return semester_count


