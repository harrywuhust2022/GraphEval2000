class Solution:
    def minimumCost(self, source: str, target: str, original: List[str], changed: List[str], cost: List[int]) -> int:
        if source == target:
            return 0  # No cost if both are already the same
        
        n = len(source)
        if n != len(target):
            return -1  # Cannot transform if lengths are different
        
        # Preprocessing transformations into a dictionary for quick lookup
        from collections import defaultdict
        import sys
        
        trans_dict = defaultdict(lambda: sys.maxsize)
        for o, c, co in zip(original, changed, cost):
            if o in trans_dict and c in trans_dict[o]:
                trans_dict[(o, c)] = min(trans_dict[(o, c)], co)  # Store the minimum cost for each transformation
            else:
                trans_dict[(o, c)] = co
        
        # Dynamic programming array
        dp = [sys.maxsize] * (n + 1)
        dp[0] = 0  # Base case: no cost to convert empty to empty
        
        for i in range(1, n + 1):
            for j in range(0, i):
                src_sub = source[j:i]
                tgt_sub = target[j:i]
                
                if (src_sub, tgt_sub) in trans_dict:
                    dp[i] = min(dp[i], (dp[j] + trans_dict[(src_sub, tgt_sub)]) if j > 0 else trans_dict[(src_sub, tgt_sub)])
        
        # Checking the final position for minimum cost
        return dp[n] if dp[n] != sys.maxsize else -1
