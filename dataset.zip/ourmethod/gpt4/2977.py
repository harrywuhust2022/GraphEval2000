class Solution:
    def minimumCost(self, source: str, target: str, original: List[str], changed: List[str], cost: List[int]) -> int:
        from collections import defaultdict
        import sys
        
        # Create mapping from original to (changed, cost)
        transformation_cost = defaultdict(list)
        for o, c, co in zip(original, changed, cost):
            transformation_cost[o].append((c, co))
        
        n = len(source)
        m = len(target)
        
        # Dynamic programming table: minimum cost to change source[0..i] to target[0..j]
        dp = [[sys.maxsize] * (m + 1) for _ in range(n + 1)]
        dp[0][0] = 0  # Cost to transform empty to empty is zero
        
        # Fill DP table
        for i in range(n + 1):
            for j in range(m + 1):
                # If not first row, inherit the cost of deleting characters from source to make it empty
                if i > 0:
                    dp[i][j] = min(dp[i][j], dp[i-1][j])
                
                # Proceed only if there are characters to consider
                if i < n and j < m:
                    # Check each transformation
                    for orig, changes in transformation_cost.items():
                        len_o = len(orig)
                        # If the current source part starts with 'orig'
                        if source[i:i+len_o] == orig:
                            for change, change_cost in changes:
                                len_c = len(change)
                                # If the current target part starts with 'change'
                                if target[j:j+len_c] == change:
                                    # Calculate cost to perform this transformation
                                    if i + len_o <= n and j + len_c <= m:
                                        dp[i+len_o][j+len_c] = min(dp[i+len_o][j+len_c], dp[i][j] + change_cost)
        
        # Result in transforming the whole source to the whole target
        result = dp[n][m]
        return result if result != sys.maxsize else -1
