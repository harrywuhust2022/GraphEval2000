from heapq import heappop, heappush
from typing import List

class Solution:
    def modifiedGraphEdges(self, n: int, edges: List[List[int]], source: int, destination: int, target: int) -> List[List[int]]:
        from collections import defaultdict
        import sys

        # Step 1: Initialize the graph
        graph = defaultdict(list)
        variable_edges = []
        
        for u, v, w in edges:
            if w != -1:
                graph[u].append((v, w))
                graph[v].append((u, w))
            else:
                variable_edges.append((u, v))

        # Helper function to calculate shortest path using Dijkstra's algorithm
        def shortest_path(source, target):
            min_heap = [(0, source)]  # (cost, node)
            shortest_distances = {node: float('inf') for node in range(n)}
            shortest_distances[source] = 0
            
            while min_heap:
                current_distance, u = heappop(min_heap)
                
                if current_distance > shortest_distances[u]:
                    continue
                
                for v, weight in graph[u]:
                    distance = current_distance + weight
                    if distance < shortest_distances[v]:
                        shortest_distances[v] = distance
                        heappush(min_heap, (distance, v))
            
            return shortest_distances[target]

        # Step 2: Calculate initial shortest path
        initial_dist = shortest_path(source, destination)
        
        if initial_dist == target:
            return [[u, v, w] for u, v, w in edges if w != -1] + [[u, v, 1] for u, v in variable_edges]
        elif initial_dist < target and variable_edges:
            # Need to add weights to the -1 edges to make up for the difference
            needed_distance = target - initial_dist
            
            # Assign weights to the -1 edges
            for u, v in variable_edges:
                weight = needed_distance if len(variable_edges) == 1 else 1
                graph[u].append((v, weight))
                graph[v].append((u, weight))
                needed_distance -= weight
