class Solution:
    def isPossible(self, n: int, edges: List[List[int]]) -> bool:
        from collections import defaultdict
        
        # Create a graph and degree counter
        graph = defaultdict(set)
        degrees = defaultdict(int)
        
        # Build the graph and calculate degrees of each node
        for a, b in edges:
            graph[a].add(b)
            graph[b].add(a)
            degrees[a] += 1
            degrees[b] += 1
        
        # Find nodes with odd degrees
        odd_degree_nodes = [node for node in range(1, n + 1) if degrees[node] % 2 != 0]
        
        # Determine the number of odd degree nodes
        odd_count = len(odd_degree_nodes)
        
        # If 0 odd degree nodes, all degrees are already even
        if odd_count == 0:
            return True
        elif odd_count == 2:
            # Directly connect two odd degree nodes if no edge exists between them
            a, b = odd_degree_nodes
            if b not in graph[a]:
                return True
            return False
        elif odd_count == 4:
            # Try to find two pairs that can be connected without an existing edge
            for i in range(4):
                for j in range(i + 1, 4):
                    a, b = odd_degree_nodes[i], odd_degree_nodes[j]
                    # Check if a and b can be connected
                    if b not in graph[a]:
                        # Now find another pair among the remaining nodes
                        remaining = odd_degree_nodes[:]
                        remaining.remove(a)
                        remaining.remove(b)
                        c, d = remaining[0], remaining[1]
                        if d not in graph[c]:
                            return True
            return False
        else:
            # More than 4 odd nodes, not possible with at most two edges
            return False