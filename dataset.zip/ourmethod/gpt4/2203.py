class Solution:
    def minimumWeight(self, n: int, edges: List[List[int]], src1: int, src2: int, dest: int) -> int:
        from collections import defaultdict
        import sys
        
        # Graph and reverse graph
        graph = defaultdict(list)
        reverse_graph = defaultdict(list)
        for u, v, w in edges:
            graph[u].append((v, w))
            reverse_graph[v].append((u, w))
        
        def dijkstra(source, graph):
            # Min-heap + shortest path distance dictionary
            min_heap = [(0, source)]  # (cost, node)
            shortest = {node: sys.maxsize for node in range(n)}
            shortest[source] = 0
            
            while min_heap:
                current_cost, u = heappop(min_heap)
                
                if current_cost > shortest[u]:
                    continue
                
                for v, weight in graph[u]:
                    if current_cost + weight < shortest[v]:
                        shortest[v] = current_cost + weight
                        heappush(min_heap, (shortest[v], v))
            
            return shortest
        
        # Get shortest path costs from dest to all nodes using the reverse graph
        shortest_to_dest = dijkstra(dest, reverse_graph)
        
        # Get shortest path costs from src1 and src2 to all nodes using the original graph
        shortest_from_src1 = dijkstra(src1, graph)
        shortest_from_src2 = dijkstra(src2, graph)
        
        # Calculate the minimum weight subgraph that can reach dest from both src1 and src2
        min_cost = sys.maxsize
        for u in range(n):
            if shortest_to_dest[u] < sys.maxsize and shortest_from_src1[u] < sys.maxsize and shortest_from_src2[u] < sys.maxsize:
                total_cost = shortest_from_src1[u] + shortest_from_src2[u] + shortest_to_dest[u]
                min_cost = min(min_cost, total_cost)
        
        return min_cost if min_cost != sys.maxsize else -1