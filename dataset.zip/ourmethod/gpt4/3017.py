class Solution:
    def countOfPairs(self, n: int, x: int, y: int) -> List[int]:
        import sys
        
        # Initialize result list
        result = [0] * n
        
        # Shortest path calculation using a simple approach suitable for this specific problem
        # Initialize distances
        dist = [[sys.maxsize] * n for _ in range(n)]
        for i in range(n):
            for j in range(n):
                if abs(i - j) == 1:
                    dist[i][j] = 1
                if i == j:
                    dist[i][j] = 0
        
        # Add the direct connection
        if x != y:
            dist[x-1][y-1] = 1
            dist[y-1][x-1] = 1
        
        # Floyd-Warshall Algorithm to find all pairs shortest paths
        for k in range(n):
            for i in range(n):
                for j in range(n):
                    if dist[i][j] > dist[i][k] + dist[k][j]:
                        dist[i][j] = dist[i][k] + dist[k][j]
        
        # Count pairs for each distance
        for i in range(n):
            for j in range(i + 1, n):
                if dist[i][j] < n:
                    result[dist[i][j] - 1] += 1
        
        # Multiply by 2 to account for (i, j) and (j, i)
        result = [2 * x for x in result]
        
        return result