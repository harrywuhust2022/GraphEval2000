from typing import List

class Solution:
    def countVisitedNodes(self, edges: List[int]) -> List[int]:
        def dfs(node: int) -> int:
            if visited[node]:
                if in_stack[node]:
                    # We've found a cycle
                    cycle_length = 0
                    current = node
                    while True:
                        cycle_length += 1
                        in_cycle[current] = True
                        current = edges[current]
                        if current == node:
                            break
                    return cycle_length
                else:
                    return answer[node]

            visited[node] = True
            in_stack[node] = True

            next_node = edges[node]
            result = dfs(next_node)

            in_stack[node] = False
            if in_cycle[node]:
                answer[node] = result
            else:
                answer[node] = result + 1
            return answer[node]
        
        n = len(edges)
        visited = [False] * n
        in_stack = [False] * n
        in_cycle = [False] * n
        answer = [0] * n

        for i in range(n):
            if not visited[i]:
                dfs(i)
        
        return answer

# Example usage
solution = Solution()
print(solution.countVisitedNodes([1, 2, 0, 0]))  # Expected output: [3, 3, 3, 4]
print(solution.countVisitedNodes([1, 2, 3, 4, 0]))  # Expected output: [5, 5, 5, 5, 5]

# Additional test cases
print(solution.countVisitedNodes([1, 0]))  # Expected output: [2, 2]
print(solution.countVisitedNodes([2, 0, 1]))  # Expected output: [3, 3, 3]
