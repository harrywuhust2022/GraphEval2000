class Solution:
    def isPossible(self, n: int, edges: List[List[int]]) -> bool:
        from collections import defaultdict
        
        # Step 1: Calculate the degree of each node
        degree = defaultdict(int)
        edge_set = set()
        
        for u, v in edges:
            degree[u] += 1
            degree[v] += 1
            edge_set.add((min(u, v), max(u, v)))
        
        # Step 2: Identify nodes with odd degrees
        odd_degree_nodes = [node for node, deg in degree.items() if deg % 2 != 0]
        
        # Step 3: Check conditions based on the number of odd degree nodes
        if len(odd_degree_nodes) == 0:
            return True
        elif len(odd_degree_nodes) == 2:
            u, v = odd_degree_nodes
            if (min(u, v), max(u, v)) not in edge_set:
                return True
            for i in range(1, n + 1):
                if i != u and i != v and (min(i, u), max(i, u)) not in edge_set and (min(i, v), max(i, v)) not in edge_set:
                    return True
            return False
        elif len(odd_degree_nodes) == 4:
            u, v, w, x = odd_degree_nodes
            possible_edges = [
                (u, v), (u, w), (u, x),
                (v, w), (v, x),
                (w, x)
            ]
            for i in range(len(possible_edges)):
                for j in range(i + 1, len(possible_edges)):
                    a, b = possible_edges[i]
                    c, d = possible_edges[j]
                    if len({a, b, c, d}) == 4 and (min(a, b), max(a, b)) not in edge_set and (min(c, d), max(c, d)) not in edge_set:
                        return True
            return False
        else:
            return False

