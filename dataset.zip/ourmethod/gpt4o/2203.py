import heapq
from typing import List, Tuple

class Solution:
    def minimumWeight(self, n: int, edges: List[List[int]], src1: int, src2: int, dest: int) -> int:
        def dijkstra(start: int, graph: List[List[Tuple[int, int]]]) -> List[int]:
            dist = [float('inf')] * n
            dist[start] = 0
            heap = [(0, start)]
            while heap:
                current_dist, u = heapq.heappop(heap)
                if current_dist > dist[u]:
                    continue
                for weight, v in graph[u]:
                    if dist[u] + weight < dist[v]:
                        dist[v] = dist[u] + weight
                        heapq.heappush(heap, (dist[v], v))
            return dist
        
        # Create graph and reversed graph
        graph = [[] for _ in range(n)]
        reverse_graph = [[] for _ in range(n)]
        
        for u, v, weight in edges:
            graph[u].append((weight, v))
            reverse_graph[v].append((weight, u))
        
        # Get shortest paths
        dist_src1 = dijkstra(src1, graph)
        dist_src2 = dijkstra(src2, graph)
        dist_dest = dijkstra(dest, reverse_graph)
        
        # Calculate minimum combined distance
        min_weight = float('inf')
        for i in range(n):
            if dist_src1[i] < float('inf') and dist_src2[i] < float('inf') and dist_dest[i] < float('inf'):
                combined_weight = dist_src1[i] + dist_src2[i] + dist_dest[i]
                min_weight = min(min_weight, combined_weight)
        
        return min_weight if min_weight < float('inf') else -1

# Test the implementation with the given examples
sol = Solution()
print(sol.minimumWeight(6, [[0,2,2],[0,5,6],[1,0,3],[1,4,5],[2,1,1],[2,3,3],[2,3,4],[3,4,2],[4,5,1]], 0, 1, 5))  # Output: 9
print(sol.minimumWeight(3, [[0,1,1],[2,1,1]], 0, 1, 2))  # Output: -1
