import heapq

class Solution:
    def minimumTime(self, grid: List[List[int]]) -> int:
        m, n = len(grid), len(grid[0])
        
        # Priority queue for Dijkstra's algorithm
        pq = [(0, 0, 0)]  # (time, x, y)
        visited = [[False] * n for _ in range(m)]
        directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]
        
        while pq:
            time, x, y = heapq.heappop(pq)
            
            # If we've reached the bottom-right cell
            if x == m - 1 and y == n - 1:
                return time
            
            # If this cell has already been visited, skip it
            if visited[x][y]:
                continue
            visited[x][y] = True
            
            # Explore the neighbors
            for dx, dy in directions:
                nx, ny = x + dx, y + dy
                if 0 <= nx < m and 0 <= ny < n:
                    new_time = max(time + 1, grid[nx][ny])
                    if not visited[nx][ny]:
                        heapq.heappush(pq, (new_time, nx, ny))
        
        # If we exhaust the priority queue without reaching the bottom-right cell
        return -1

# Example test cases
grid1 = [[0, 1, 3, 2], [5, 1, 2, 5], [4, 3, 8, 6]]
grid2 = [[0, 2, 4], [3, 2, 1], [1, 0, 4]]

solution = Solution()
print(solution.minimumTime(grid1))  # Output: 7
print(solution.minimumTime(grid2))  # Output: -1
