class Solution:
    def findShortestCycle(self, n: int, edges: List[List[int]]) -> int:
        # Step 1: Create the graph using an adjacency list
        graph = defaultdict(list)
        for u, v in edges:
            graph[u].append(v)
            graph[v].append(u)

        # Step 2: Find the shortest cycle using BFS from each vertex
        shortest_cycle = float('inf')
        
        for start in range(n):
            # BFS setup
            queue = deque([(start, -1, 0)])  # (current vertex, parent vertex, current depth)
            visited = {}
            
            while queue:
                current, parent, depth = queue.popleft()
                
                if current in visited:
                    # If we find a previously visited node, we have a cycle
                    if visited[current] != parent:  # Ensure we're not considering the immediate parent
                        # Cycle length calculation
                        cycle_length = depth + visited[current]
                        shortest_cycle = min(shortest_cycle, cycle_length)
                    continue

                # Mark the current node as visited with its depth
                visited[current] = depth
                
                # Enqueue all adjacent vertices
                for neighbor in graph[current]:
                    if neighbor != parent:  # Don't go back immediately to the parent
                        queue.append((neighbor, current, depth + 1))

        # Step 4: Return the result
        return -1 if shortest_cycle == float('inf') else shortest_cycle