from heapq import heappush, heappop
import sys

class Solution:
    def modifiedGraphEdges(self, n: int, edges: List[List[int]], source: int, destination: int, target: int) -> List[List[int]]:
        # Initialize graph as adjacency list
        graph = [[] for _ in range(n)]
        for edge in edges:
            u, v, w = edge
            graph[u].append((v, w))
            graph[v].append((u, w))

        def dijkstra(graph, src):
            dist = [sys.maxsize] * len(graph)
            dist[src] = 0
            pq = [(0, src)]  # (distance, node)
            
            while pq:
                d, u = heappop(pq)
                if d > dist[u]:
                    continue
                for v, weight in graph[u]:
                    if weight == -1:
                        continue  # Skip -1 weights for now
                    if dist[u] + weight < dist[v]:
                        dist[v] = dist[u] + weight
                        heappush(pq, (dist[v], v))
            
            return dist

        # Calculate shortest path ignoring -1 weights
        initial_dist = dijkstra(graph, source)
        
        if initial_dist[destination] < target:
            return []
        
        # Try to adjust weights of -1 edges
        # (1) Calculate shortest path without -1 edges
        for i, edge in enumerate(edges):
            if edge[2] == -1:
                edges[i][2] = 1
        
        dist = dijkstra(graph, source)
        if dist[destination] > target:
            return []
        
        # (2) Use a modified Dijkstra's to adjust -1 edges to make shortest path equal to target
        for i, edge in enumerate(edges):
            if edge[2] == 1:
                edge[2] = -1  # Revert to original -1

        def modified_dijkstra():
            dist = [sys.maxsize] * len(graph)
            dist[source] = 0
            pq = [(0, source)]
            prev_edge = [None] * len(graph)
            
            while pq:
                d, u = heappop(pq)
                if d > dist[u]:
                    continue
                for i, (v, weight) in enumerate(graph[u]):
                    if weight == -1:
                        weight = 1  # Temporarily set -1 weight to 1
                    if dist[u] + weight < dist[v]:
                        dist[v] = dist[u] + weight
                        heappush(pq, (dist[v], v))
                        prev_edge[v] = (u, i)
            
            return dist, prev_edge

        dist, prev_edge = modified_dijkstra()
        
        if dist[destination] == target:
            for i, edge in enumerate(edges):
                if edge[2] == -1:
                    edge[2] = 1  # Set all -1 edges to 1 if already achieved target
            return edges
        
        # Find the difference we need to adjust
        difference = target - dist[destination]
        if difference < 0:
            return []

        # Adjust the weights of -1 edges
        path = []
        v = destination
        while prev_edge[v] is not None:
            u, i = prev_edge[v]
            if edges[i][2] == -1:
                path.append((u, v))
            v = u
        
        if not path:
            return []

        for u, v in path:
            for i, (n, w) in enumerate(graph[u]):
                if n == v and w == -1:
                    graph[u][i] = (v, 1 + difference)
                    break
            for i, (n, w) in enumerate(graph[v]):
                if n == u and w == -1:
                    graph[v][i] = (u, 1 + difference)
                    break
        
        dist, _ = modified_dijkstra()
        if dist[destination] == target:
            for i, edge in enumerate(edges):
                if edge[2] == -1:
                    edge[2] = 1 + difference
            return edges


