class Solution:
    def minimumCost(self, source: str, target: str, original: List[str], changed: List[str], cost: List[int]) -> int:
        n = len(source)
        dp = [float('inf')] * (n + 1)
        dp[0] = 0
        
        transform_map = {}
        for o, c, z in zip(original, changed, cost):
            if o in transform_map:
                transform_map[o].append((c, z))
            else:
                transform_map[o] = [(c, z)]
        
        for i in range(n):
            if dp[i] == float('inf'):
                continue
            for length in range(1, n - i + 1):
                sub_source = source[i:i + length]
                sub_target = target[i:i + length]
                if sub_source == sub_target:
                    dp[i + length] = min(dp[i + length], dp[i])
                if sub_source in transform_map:
                    for (c, z) in transform_map[sub_source]:
                        if c == sub_target:
                            dp[i + length] = min(dp[i + length], dp[i] + z)
        
        return dp[n] if dp[n] != float('inf') else -1