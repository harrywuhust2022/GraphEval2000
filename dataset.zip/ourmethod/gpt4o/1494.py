from collections import deque, defaultdict

def minNumberOfSemesters(n, relations, k):
    # Step 1: Build graph and in-degree array
    graph = defaultdict(list)
    in_degree = [0] * (n + 1)
    
    for u, v in relations:
        graph[u].append(v)
        in_degree[v] += 1
    
    # Step 2: Initialize the queue with courses having zero prerequisites
    queue = deque()
    for course in range(1, n + 1):
        if in_degree[course] == 0:
            queue.append(course)
    
    # Step 3: Process courses semester-wise
    semesters = 0
    while queue:
        semesters += 1
        # We can take up to k courses in the current semester
        num_courses = min(len(queue), k)
        for _ in range(num_courses):
            course = queue.popleft()
            for next_course in graph[course]:
                in_degree[next_course] -= 1
                if in_degree[next_course] == 0:
                    queue.append(next_course)
    
    return semesters

