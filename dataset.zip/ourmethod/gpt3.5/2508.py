from collections import defaultdict

class Solution:
    def isPossible(self, n: int, edges: List[List[int]]) -> bool:
        # Step 1: Calculate the degree of each node
        degrees = defaultdict(int)
        for edge in edges:
            degrees[edge[0]] += 1
            degrees[edge[1]] += 1
        
        # Step 2: Check if the degree of each node is even
        for degree in degrees.values():
            if degree % 2 != 0:
                odd_degree_count = sum(1 for d in degrees.values() if d % 2 != 0)
                if odd_degree_count > 2:
                    return False
        
        # Step 3: Handle Disconnected Components
        visited = set()
        components = []
        for node in range(1, n+1):
            if node not in visited:
                component = set()
                stack = [node]
                while stack:
                    current_node = stack.pop()
                    if current_node not in visited:
                        visited.add(current_node)
                        component.add(current_node)
                        stack.extend([neighbor for neighbor in range(1, n+1) if ([current_node, neighbor] in edges or [neighbor, current_node] in edges) and neighbor not in visited])
                components.append(component)
        
        # Step 4: Check Additional Edges
        odd_components = [component for component in components if sum(degrees[node] for node in component) % 2 != 0]
        if len(odd_components) == 0:
            return True
        elif len(odd_components) == 1:
            return len(odd_components[0]) <= 2
        elif len(odd_components) == 2:
            return sum(1 for node in odd_components[0] if node in odd_components[1]) < 2
        
        return False
