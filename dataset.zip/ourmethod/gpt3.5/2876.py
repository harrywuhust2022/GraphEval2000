class Solution:
    def countVisitedNodes(self, edges: List[int]) -> List[int]:
        def dfs(node, visited):
            if visited[node]:
                return
            visited[node] = True
            dfs(edges[node], visited)
        
        n = len(edges)
        visited_nodes = [0] * n
        
        for i in range(n):
            visited = [False] * n
            dfs(i, visited)
            visited_nodes[i] = sum(visited)
        
        return visited_nodes