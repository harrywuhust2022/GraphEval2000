from typing import List

class Solution:
    def countOfPairs(self, n: int, x: int, y: int) -> List[int]:
        result = [0] * n
        dist = abs(x - y) - 1
        for k in range(1, n + 1):
            for i in range(1, n):
                for j in range(i + 1, n + 1):
                    d = abs(i - j) - 1
                    if d == k:
                        result[k - 1] += 1
        return result
