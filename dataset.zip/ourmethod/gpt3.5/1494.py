class Solution:
    def minNumberOfSemesters(self, n: int, relations: List[List[int]], k: int) -> int:
        from collections import deque, defaultdict

        from typing import List

        # Function to construct the graph
        def construct_graph(n, relations):
            graph = defaultdict(list)
            for prev, next in relations:
                graph[prev].append(next)
            return graph
        
        # Function for topological sort with semester limit
        def topological_sort_with_limit(graph, k):
            indegree = defaultdict(int)
            for node in graph:
                for neighbor in graph[node]:
                    indegree[neighbor] += 1

            queue = deque([node for node in indegree if indegree[node] == 0])
            semesters = 0
            while queue:
                courses_this_semester = min(k, len(queue))
                for _ in range(courses_this_semester):
                    current = queue.popleft()
                    for neighbor in graph[current]:
                        indegree[neighbor] -= 1
                        if indegree[neighbor] == 0:
                            queue.append(neighbor)
                semesters += 1
            return semesters
        
        # Main function to calculate minimum semesters
        def min_semesters(n, relations, k):
            graph = construct_graph(n, relations)
            return topological_sort_with_limit(graph, k)

        # Call main function to get the result
        return min_semesters(n, relations, k)
