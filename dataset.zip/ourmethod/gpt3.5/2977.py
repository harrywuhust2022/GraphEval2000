from typing import List

class Solution:
    def minimumCost(self, source: str, target: str, original: List[str], changed: List[str], cost: List[int]) -> int:
        n = len(source)
        dp = [[float('inf')] * (n + 1) for _ in range(n + 1)]
        dp[0][0] = 0
        
        for i in range(n + 1):
            for j in range(n + 1):
                if i < n and j < n and source[i] == target[j]:
                    dp[i + 1][j + 1] = min(dp[i + 1][j + 1], dp[i][j])
                
                for k in range(len(original)):
                    for a in range(1, min(n - i, len(original[k]) - 1) + 1):
                        for b in range(1, min(n - j, len(changed[k]) - 1) + 1):
                            if original[k][:a] == source[i:i + a] and changed[k][:b] == target[j:j + b]:
                                dp[i + a][j + b] = min(dp[i + a][j + b], dp[i][j] + cost[k])
        
        return dp[n][n] if dp[n][n] != float('inf') else -1

# Test cases
solution = Solution()
print(solution.minimumCost("abcd", "acbe", ["a","b","c","c","e","d"], ["b","c","b","e","b","e"], [2,5,5,1,2,20]))  # Output: 28
print(solution.minimumCost("abcdefgh", "acdeeghh", ["bcd","fgh","thh"], ["cde","thh","ghh"], [1,3,5]))          # Output: 9
