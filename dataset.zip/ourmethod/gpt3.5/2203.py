class Solution:
    def minimumWeight(self, n: int, edges: List[List[int]], src1: int, src2: int, dest: int) -> int:
        # Step 1: Identify Reachable Nodes
        reachable_from_src1 = self.bfs(src1, edges, n)
        reachable_from_src2 = self.bfs(src2, edges, n)
        
        # Step 2 & 3: Generate Subgraphs and Calculate Weights
        min_weight = float('inf')
        for node1 in reachable_from_src1:
            for node2 in reachable_from_src2:
                if node1 == node2:  # Common reachable node
                    subgraph_weight = self.calculate_subgraph_weight(node1, edges, src1, src2, dest)
                    if subgraph_weight != -1:  # If subgraph satisfies constraints
                        min_weight = min(min_weight, subgraph_weight)
        
        # Step 4: Return Minimum Weight
        return min_weight if min_weight != float('inf') else -1
    
    def bfs(self, start: int, edges: List[List[int]], n: int) -> set:
        reachable = set()
        queue = [start]
        visited = set()
        
        while queue:
            node = queue.pop(0)
            reachable.add(node)
            visited.add(node)
            for edge in edges:
                if edge[0] == node and edge[1] not in visited:
                    queue.append(edge[1])
        
        return reachable
    
    def calculate_subgraph_weight(self, common_node: int, edges: List[List[int]], src1: int, src2: int, dest: int) -> int:
        subgraph_weight = 0
        src1_to_common_weight = float('inf')
        src2_to_common_weight = float('inf')
        
        for edge in edges:
            if edge[1] == common_node:
                if edge[0] == src1:
                    src1_to_common_weight = min(src1_to_common_weight, edge[2])
                elif edge[0] == src2:
                    src2_to_common_weight = min(src2_to_common_weight, edge[2])
        
        for edge in edges:
            if edge[2] < src1_to_common_weight or edge[2] < src2_to_common_weight:
                if edge[1] == dest and edge[0] in (src1, src2):
                    subgraph_weight += edge[2]
                elif edge[1] == common_node and edge[0] in (src1, src2):
                    subgraph_weight += edge[2]
        
        return subgraph_weight if subgraph_weight != 0 else -1