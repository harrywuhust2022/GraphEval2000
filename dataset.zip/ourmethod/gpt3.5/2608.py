from typing import List
from collections import deque

class Solution:
    def findShortestCycle(self, n: int, edges: List[List[int]]) -> int:
        # Step 1: Create adjacency list representation of the graph
        adj_list = [[] for _ in range(n)]
        for u, v in edges:
            adj_list[u].append(v)
            adj_list[v].append(u)
        
        # Step 2: Perform BFS from each vertex to find shortest cycle
        min_cycle_length = float('inf')
        for start in range(n):
            queue = deque([(start, 0)])
            visited = {start}
            while queue:
                node, dist = queue.popleft()
                for neighbor in adj_list[node]:
                    if neighbor == start:
                        min_cycle_length = min(min_cycle_length, dist + 1)
                    elif neighbor not in visited:
                        visited.add(neighbor)
                        queue.append((neighbor, dist + 1))
        
        # Step 5: Return the minimum cycle length found, or -1 if no cycle exists
        return min_cycle_length if min_cycle_length != float('inf') else -1

# Test cases
sol = Solution()
print(sol.findShortestCycle(7, [[0,1],[1,2],[2,0],[3,4],[4,5],[5,6],[6,3]]))  # Output: 3
print(sol.findShortestCycle(4, [[0,1],[0,2]]))  # Output: -1
