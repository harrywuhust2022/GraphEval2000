from heapq import heappush, heappop
from typing import List

class Solution:
    def minimumTime(self, grid: List[List[int]]) -> int:
        m, n = len(grid), len(grid[0])
        earliest = [[float('inf')] * n for _ in range(m)]
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
        heap = [(0, 0, 0)]  # (time, row, col)
        earliest[0][0] = 0
        
        while heap:
            t, r, c = heappop(heap)
            if (r, c) == (m-1, n-1):
                return t
            for dr, dc in directions:
                nr, nc = r + dr, c + dc
                if 0 <= nr < m and 0 <= nc < n:
                    nt = max(t + 1, grid[nr][nc])
                    if nt < earliest[nr][nc]:
                        earliest[nr][nc] = nt
                        heappush(heap, (nt, nr, nc))
        
        return -1